import { useEffect, useMemo, useRef, useState } from 'react'
import * as XLSX from 'xlsx'
import Kit from './lib/kit.js'
import { topo } from './lib/fx.js'
import { aoaToObjects, inferType, num, parseCSV, specimen } from './lib/sheet.js'
import Chart from './components/Chart'
import Kpis from './components/Kpis'
import type { Field, Row, Sheets } from './lib/types'

const T: Record<string, string> = { number: '数值', date: '日期', text: '分类' }
const MARK = (
  <svg viewBox="0 0 22 22" fill="none" stroke="currentColor" strokeWidth="1.6">
    <rect x="2" y="2" width="18" height="18" /><path d="M7 15V7m4 8V7m4 8V7" strokeLinecap="square" />
  </svg>
)

function fieldsOf(rows: Row[]): Field[] {
  const cols = [...new Set(rows.flatMap(r => Object.keys(r)))]
  return cols.map(c => {
    const vals = rows.map(r => r[c])
    return { name: c, type: inferType(vals), uniq: new Set(vals.map(v => String(v ?? ''))).size }
  })
}

export default function App() {
  const [sheets, setSheets] = useState<Sheets>(() => specimen())
  const [src, setSrc] = useState('SPECIMEN')
  const [active, setActive] = useState(() => Object.keys(sheets)[0])
  const [fields, setFields] = useState<Field[]>(() => fieldsOf(sheets[Object.keys(sheets)[0]]))
  const [filters, setFilters] = useState<Record<string, string>>({})
  const [err, setErr] = useState('')
  const [over, setOver] = useState(false)

  const dropEl = useRef<HTMLDivElement>(null)
  const fileIn = useRef<HTMLInputElement>(null)
  const themeSlot = useRef<HTMLSpanElement>(null)

  /* 等高线场在背景里自己流动 —— 这一层是 canvas，交给 fx.js。 */
  useEffect(() => { topo(dropEl.current, { step: 24, levels: 6, speed: .05, alpha: .5 }) }, [])
  useEffect(() => { Kit.themeToggle(() => {}, themeSlot.current); Kit.reveal() }, [])

  const load = (next: Sheets, nextSrc: string) => {
    const first = Object.keys(next)[0]
    setSheets(next); setSrc(nextSrc); setActive(first)
    setFields(fieldsOf(next[first])); setFilters({}); setErr('')
  }
  const pickSheet = (n: string) => { setActive(n); setFields(fieldsOf(sheets[n])); setFilters({}) }

  const rows: Row[] = sheets[active] || []
  const shown = useMemo(
    () => rows.filter(r => Object.entries(filters).every(([k, v]) => !v || String(r[k] ?? '') === v)),
    [rows, filters])

  const nums = fields.filter(f => f.type === 'number')
  const datef = fields.find(f => f.type === 'date')
  const catf = fields.find(f => f.type === 'text')
  const numf = nums[0]

  /* ── 走势 / 排行 ─────────────────────────────────────────────────────── */
  const trend = useMemo(() => {
    if (!datef || !numf) return null
    const agg: Record<string, number> = {}
    shown.forEach(r => {
      const d = String(r[datef.name] ?? '').slice(0, 10), v = num(r[numf.name])
      if (d && v !== null) agg[d] = (agg[d] || 0) + v
    })
    return { ks: Object.keys(agg).sort(), agg }
  }, [shown, datef, numf])
  const trendOpt = () => {
    const { ks, agg } = trend!, ink = Kit.css('s1')
    return {
      xAxis: Kit.axis('category', { data: ks, boundaryGap: false }),
      yAxis: Kit.axis('value'),
      series: [{ type: 'line', data: ks.map(k => +agg[k].toFixed(2)), showSymbol: false, symbol: 'circle', symbolSize: 5,
        lineStyle: { color: ink, width: 1.5 }, itemStyle: { color: ink },
        areaStyle: { color: ink, opacity: .06 } }],
    }
  }
  const rankTop = useMemo(() => {
    if (!catf || !numf) return null
    const agg: Record<string, number> = {}
    shown.forEach(r => {
      const k = String(r[catf.name] ?? '∅'), v = num(r[numf.name])
      if (v !== null) agg[k] = (agg[k] || 0) + v
    })
    return Object.entries(agg).sort((a, b) => b[1] - a[1]).slice(0, 8)
  }, [shown, catf, numf])
  const rankOpt = () => {
    const ink = Kit.css('s1'), accent = Kit.css('accent')
    return {
      grid: { left: 8, right: 48, top: 8, bottom: 4, containLabel: true },
      xAxis: Kit.axis('value'),
      yAxis: Kit.axis('category', { data: rankTop!.map(t => t[0]).reverse(), axisLabel: { color: Kit.css('muted'), fontSize: 11 } }),
      series: [{ type: 'bar', barWidth: '52%', data: rankTop!.map((t, i) => ({ value: +t[1].toFixed(2),
        itemStyle: { color: i === 0 ? accent : ink, opacity: i === 0 ? 1 : .85 - i * .07 } })).reverse(),
        label: { show: true, position: 'right', fontFamily: Kit.css('mono'), fontSize: 10, color: Kit.css('faint'),
          formatter: (p: { value: number }) => Kit.compact(p.value) } }],
    }
  }

  /* ── 取文件 ──────────────────────────────────────────────────────────── */
  const fail = (msg: string) => setErr(msg)
  const take = async (f: File) => {
    try {
      const next: Sheets = {}
      if (/\.csv$/i.test(f.name)) {
        let text = await f.text()
        if ((text.match(/�/g) || []).length > 10) {
          const buf = await f.arrayBuffer()
          try { text = new TextDecoder('gbk').decode(buf) } catch { /* 编码猜错就用原文 */ }
        }
        const aoa = parseCSV(text.replace(/^﻿/, ''))
        if (aoa.length < 2) return fail('CSV 里没有有效数据行。')
        next[f.name.replace(/\.csv$/i, '')] = aoaToObjects(aoa)
      } else {
        const wb = XLSX.read(await f.arrayBuffer(), { type: 'array' })
        if (!wb.SheetNames.length) return fail('工作簿里没有 sheet。')
        wb.SheetNames.forEach(n => {
          const objs = aoaToObjects(XLSX.utils.sheet_to_json(wb.Sheets[n], { header: 1, defval: null, raw: true }))
          if (objs.length) next[n] = objs
        })
        if (!Object.keys(next).length) return fail('所有 sheet 都是空的。')
      }
      // 空列过多时给出指向性提示
      for (const [sn, rs] of Object.entries(next)) {
        const cols = Object.keys(rs[0] || {})
        const blank = cols.filter(c => rs.every(r => r[c] === null || r[c] === undefined || r[c] === ''))
        if (blank.length && blank.length >= cols.length / 2)
          Kit.toast(`提示:${sn} 有 ${blank.length} 列全空(${blank[0]} 等),已保留`)
      }
      load(next, f.name.length > 22 ? f.name.slice(0, 20) + '…' : f.name)
      Kit.toast('已解析 ' + f.name)
    } catch (e) {
      console.error(e)
      fail((e as Error)?.message || '文件无法读取。')
    }
  }

  const cats = fields.filter(f => f.type === 'text' && f.uniq > 1 && f.uniq <= 40).slice(0, 2)
  const tblRows = shown.slice(0, 200)

  return (
    <>
      <header>
        <div className="htop">
          <span className="mark">{MARK}</span>
          <h1>数据手稿<small>Data Manuscript · xlsx / csv → dashboard</small></h1>
          <div className="spacer" />
          <div className="sheets" id="sheets">
            {Object.keys(sheets).map(n => (
              <button key={n} data-v={n} className={n === active ? 'on' : undefined}
                      onClick={() => pickSheet(n)}>{n}</button>
            ))}
          </div>
          <button className="btn" id="btn-sample"
                  onClick={() => { load(specimen(), 'SPECIMEN'); Kit.toast('示例数据已载入') }}>载入示例</button>
          <button className="btn primary" id="btn-open" onClick={() => fileIn.current?.click()}>打开文件…</button>
          <span id="theme-slot" ref={themeSlot} />
        </div>
      </header>

      <div className="app">
        <aside className="rail">
          <div className="fig"><b>FIG. 1</b><span>INPUT SPECIMEN</span>
            <span className="tail" id="fig1-tail">{err ? 'SPECIMEN REJECTED' : 'SPECIMEN LOADED'}</span></div>
          <div className={'drop' + (err ? ' error' : '') + (over ? ' over' : '')} id="drop" data-e2e="file" ref={dropEl}
               onClick={e => { if ((e.target as HTMLElement).closest('.err')) return; fileIn.current?.click() }}
               onDragOver={e => { e.preventDefault(); setOver(true) }}
               onDragEnter={e => { e.preventDefault(); setOver(true) }}
               onDragLeave={e => { e.preventDefault(); setOver(false) }}
               onDrop={e => { e.preventDefault(); setOver(false); const f = e.dataTransfer.files[0]; if (f) take(f) }}>
            <div className="err" id="err">
              {err ? <><b>解析失败</b><br />{err}</> : null}
            </div>
            <div className="pad">
              <div className="ok">
                <h3 id="drop-title">
                  {src === 'SPECIMEN' ? '示例数据已载入 · 拖入文件替换' : '已载入 ' + src}</h3>
                <p>纯前端解析,数据不离开本页。多 sheet 工作簿自动拆成页签,字段类型自动推断,无需配置直接出图。</p>
                <div className="k" id="drop-meta">CLICK OR DROP · UTF-8 / GBK</div>
              </div>
            </div>
            <input type="file" id="file" accept=".csv,.xlsx,.xls" hidden ref={fileIn}
                   onChange={e => { const f = e.target.files?.[0]; if (f) take(f); e.target.value = '' }} />
          </div>

          <div className="fig"><b>FIG. 1B</b><span>FIELD INFERENCE</span>
            <span className="tail" id="field-count">{fields.length + ' COLS'}</span></div>
          <div className="fields" id="fields">
            {fields.map(f => (
              <div className="frow" key={f.name}>
                <div><div className="nm" title={f.name}>{f.name}</div><div className="un">{f.uniq + ' UNIQUE'}</div></div>
                <select value={f.type} onChange={e => {
                  const t = e.target.value as Field['type']
                  setFields(fs => fs.map(x => x.name === f.name
                    ? { ...x, type: t, uniq: new Set(rows.map(r => String(r[f.name] ?? ''))).size } : x))
                  setFilters({})
                }}>
                  {(['number', 'date', 'text'] as const).map(t => <option key={t} value={t}>{T[t]}</option>)}
                </select>
              </div>
            ))}
          </div>

          <div className="fig"><b>FIG. 1C</b><span>GLOBAL FILTERS</span></div>
          <div className="fields" id="filters">
            {!cats.length ? <div className="frow"><span className="un">无可筛选分类列</span></div>
              : cats.map(f => (
                <div className="frow" key={f.name}>
                  <div><div className="nm">{f.name}</div><div className="un">FILTER</div></div>
                  <select style={{ maxWidth: '130px' }} value={filters[f.name] || ''}
                          onChange={e => setFilters(m => ({ ...m, [f.name]: e.target.value }))}>
                    <option value="">全部</option>
                    {[...new Set(rows.map(r => String(r[f.name] ?? '')))].sort()
                      .map(v => <option key={v}>{v}</option>)}
                  </select>
                </div>
              ))}
          </div>
        </aside>

        <main className="main">
          <section className="kpis" id="kpis">
            <Kpis rows={shown} nums={nums} datef={datef} />
          </section>

          <section className="row2">
            <section className="pane">
              <div className="fig"><b>FIG. 2</b><span id="trend-cap">
                {trend ? `TREND · ${datef!.name} × ${numf.name}` : 'TREND · 需要一列日期 + 一列数值'}</span></div>
              {trend ? <Chart id="c-trend" className="body" build={trendOpt} deps={[trend]} />
                     : <div className="body" id="c-trend" />}
            </section>
            <section className="pane">
              <div className="fig"><b>FIG. 3</b><span id="rank-cap">
                {rankTop ? `RANK · ${catf!.name} × ${numf.name}` : 'RANK · 需要一列分类 + 一列数值'}</span></div>
              {rankTop ? <Chart id="c-rank" className="body" build={rankOpt} deps={[rankTop]} />
                       : <div className="body" id="c-rank" />}
            </section>
          </section>

          <section className="pane">
            <div className="fig"><b>FIG. 4</b><span>DETAIL</span>
              <span className="tail" id="tbl-cap">
                {`SHOWING ${tblRows.length} / ${Kit.fmt(shown.length)} ROWS · CLICK HEADER TO SORT`}</span></div>
            <div className="twrap">
              <table id="tbl">
                <thead><tr>{fields.map(f => (
                  <th key={f.name} data-sort={f.type === 'number' ? 'n' : 't'}
                      className={f.type === 'number' ? 'n' : ''}>{f.name}</th>
                ))}</tr></thead>
                <tbody>{tblRows.map((r, i) => (
                  <tr key={i}>{fields.map(f => {
                    const v = r[f.name]
                    const isN = f.type === 'number' && num(v) !== null
                    return <td key={f.name} className={isN ? 'n' : ''}>
                      {isN ? Kit.fmt(num(v), String(v).includes('.') ? 2 : 0) : (v ?? '') as React.ReactNode}</td>
                  })}</tr>
                ))}</tbody>
              </table>
            </div>
          </section>
        </main>
      </div>

      <footer>
        <span>VOL. <b>01</b></span><span>ROWS <b id="f-rows">{Kit.fmt(rows.length)}</b></span>
        <span>COLS <b id="f-cols">{fields.length}</b></span>
        <span>SOURCE <b id="f-src">{src}</b></span>
        <span style={{ marginLeft: 'auto' }}>OBSERVATIONS RENDERED LOCALLY · NO UPLOAD</span>
      </footer>
    </>
  )
}
