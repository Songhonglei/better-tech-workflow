export type Row = Record<string, unknown>
export interface Field { name: string; type: 'number' | 'date' | 'text'; uniq: number }
export type Sheets = Record<string, Row[]>
