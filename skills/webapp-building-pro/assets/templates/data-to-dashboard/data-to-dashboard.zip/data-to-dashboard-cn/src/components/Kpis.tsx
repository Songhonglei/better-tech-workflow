import { useEffect, useRef } from 'react'
import Kit from '../lib/kit.js'
import { num, sparkOf } from '../lib/sheet.js'
import type { Field, Row } from '../lib/types'

/* 数字是滚上去的 —— Kit.count 直接写 DOM，所以这一格交给它，React 不去重画。 */
function Value({ v }: { v: number }) {
  const el = useRef<HTMLDivElement>(null)
  useEffect(() => { Kit.count(el.current, v, { d: 0, ms: 520 }) }, [v])
  return <div className="v" data-v="0" ref={el}>0</div>
}

function Spark({ vals }: { vals: number[] }) {
  if (!vals || vals.length < 2 || !vals.some(v => v)) return null
  const mx = Math.max(...vals)
  const pts = vals.map((v, i) => `${(i / (vals.length - 1) * 100).toFixed(1)},${(20 - v / mx * 18).toFixed(1)}`).join(' ')
  return (
    <svg className="sp" viewBox="0 0 100 20" preserveAspectRatio="none" aria-hidden="true">
      <polygon points={`0,20 ${pts} 100,20`} /><polyline points={pts} />
    </svg>
  )
}

export default function Kpis({ rows, nums, datef }: {
  rows: Row[]; nums: Field[]; datef?: Field
}) {
  const cells = nums.slice(0, 4).map(f => {
    const vs = rows.map(r => num(r[f.name])).filter((v: number | null) => v !== null) as number[]
    return { l: f.name, v: vs.reduce((a, b) => a + b, 0), d: Kit.fmt(vs.length) + ' NON-NULL', spark: sparkOf(rows, f, datef) }
  })
  while (cells.length < 4) cells.push({ l: '—', v: 0, d: 'NO NUMERIC FIELD', spark: [] })
  return (
    <>
      {cells.map((c, i) => (
        <div className="kpi" key={i}>
          <div className="l">{c.l}</div>
          <Value v={c.v} />
          <div className="d">{c.d}</div>
          <Spark vals={c.spark} />
        </div>
      ))}
    </>
  )
}
