import { createServer } from "vite";

let host = "0.0.0.0";
let port = 3000;
const args = process.argv.slice(2);
for (let i = 0; i < args.length; i++) {
  if (args[i] === "--host") host = args[++i];
  if (args[i] === "--port") port = Number(args[++i]);
}
const server = await createServer({ server: { host, port, strictPort: true } });
await server.listen();
server.printUrls();
