import { build } from "vite";
import { cpSync, rmSync } from "node:fs";

await build();
// Keep the package root runnable without a separate build step.
rmSync("assets", { recursive: true, force: true });
cpSync("dist/assets", "assets", { recursive: true });
cpSync("dist/index.html", "index.html");
