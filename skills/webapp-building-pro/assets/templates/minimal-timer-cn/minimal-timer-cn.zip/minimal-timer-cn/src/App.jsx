import React, { useLayoutEffect } from "react";
import T from "../i18n.js";
import { initializeTimer } from "../app.js";

export default function App() {
  useLayoutEffect(() => initializeTimer(), []);
  return (<>
<picture className="wallpaper" aria-hidden="true">
    <img src="assets/soft-horizon-4k.webp?v=e82875685fd0" width="3840" height="2160" alt="" fetchPriority="high" decoding="async" />
  </picture>
  <div className="sweep" id="sweep" aria-hidden="true">
    <div className="dial"></div>
    <div className="sector" id="sector"></div>
  </div>

  <nav className="seg" id="seg" aria-label={T.modeSwitch}>
    <div className="seg-thumb" id="seg-thumb"></div>
    <button data-mode="countdown" className="active"></button>
    <button data-mode="stopwatch"></button>
    <button data-mode="clock"></button>
  </nav>

  <main className="stage">
    <div className="time" id="time">00:00</div>
    <div className="laps" id="laps"></div>
  </main>

  <div className="controls">
    <button className="lap" id="lap">
      <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M5 21V4" />
        <path d="M5 4h12l-2.5 4L17 12H5" />
      </svg>
    </button>
    <button className="reset" id="reset">
      <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
        <path d="M4.5 8.5a8 8 0 1 1-.5 6.8" />
        <path d="M4.5 3.8v4.7h4.7" strokeLinejoin="round" />
      </svg>
    </button>
    <button className="toggle" id="toggle">
      <svg id="icon-pause" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
        <path d="M8 5.5v13M16 5.5v13" />
      </svg>
      <svg id="icon-play" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" style={{display:"none"}}>
        <path d="M8 5.5 18 12 8 18.5Z" />
      </svg>
    </button>
  </div>

  <button className="theme-toggle" id="theme-toggle" type="button" aria-label={T.darkMode} title={T.darkMode}>
    <svg className="theme-sun" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
      <circle cx="12" cy="12" r="3.5" />
      <path d="M12 2v2m0 16v2M2 12h2m16 0h2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42" />
    </svg>
    <svg className="theme-moon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20.2 15.1A8.4 8.4 0 0 1 8.9 3.8a8.5 8.5 0 1 0 11.3 11.3Z" />
    </svg>
  </button>

  <div className="sheet-overlay" id="sheet">
    <div className="sheet">
      <div className="sheet-header">
        <button className="sheet-btn" id="cancel"></button>
        <span className="sheet-title"></span>
        <button className="sheet-btn primary" id="confirm"></button>
      </div>
      <div className="wheels">
        <div className="wheel-col">
          <div className="wheel" id="wheel-h"></div>
          <span className="unit" data-unit="h"></span>
        </div>
        <div className="wheel-col">
          <div className="wheel" id="wheel-m"></div>
          <span className="unit" data-unit="m"></span>
        </div>
        <div className="wheel-col">
          <div className="wheel" id="wheel-s"></div>
          <span className="unit" data-unit="s"></span>
        </div>
        <div className="wheel-highlight"></div>
      </div>
    </div>
  </div>
  </>);
}
