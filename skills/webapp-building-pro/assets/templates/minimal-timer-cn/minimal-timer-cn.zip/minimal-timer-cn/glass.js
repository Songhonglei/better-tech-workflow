// Rounded glass optics adapted from Liquid Glass Studio (MIT, Charles Yin).
// See THIRD_PARTY_NOTICES.md for the license and source.
export function createGlassFX() {
  "use strict";

  const clamp = (x, low = 0, high = 1) => Math.min(high, Math.max(low, x));
  const mounted = new WeakMap();
  const cleanups = [];
  const listeners = new AbortController();
  function listen(target, name, callback) {
    target?.addEventListener(name, callback, { signal: listeners.signal });
  }
  const wallpaper = document.querySelector(".wallpaper img");
  const redraws = new Set();
  let texture = null;

  function backdrop() {
    if (!wallpaper?.complete || !wallpaper.naturalWidth) return null;
    if (texture?.source === wallpaper.currentSrc) return texture;
    const canvas = document.createElement("canvas");
    const samplingScale = Math.min(1, 2048 / wallpaper.naturalWidth);
    canvas.width = Math.round(wallpaper.naturalWidth * samplingScale);
    canvas.height = Math.round(wallpaper.naturalHeight * samplingScale);
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) return null;
    try {
      ctx.drawImage(wallpaper, 0, 0, canvas.width, canvas.height);
      texture = {
        source: wallpaper.currentSrc,
        width: canvas.width,
        height: canvas.height,
        pixels: ctx.getImageData(0, 0, canvas.width, canvas.height).data,
      };
      return texture;
    } catch {
      return null; // Keep the optical rim if the image cannot be sampled.
    }
  }

  listen(wallpaper, "load", () => {
    texture = null;
    redraws.forEach((redraw) => redraw());
  });

  function sample(map, x, y, channel) {
    const sx = clamp(x, 0, map.width - 1);
    const sy = clamp(y, 0, map.height - 1);
    const x0 = Math.floor(sx);
    const y0 = Math.floor(sy);
    const x1 = Math.min(x0 + 1, map.width - 1);
    const y1 = Math.min(y0 + 1, map.height - 1);
    const dx = sx - x0;
    const dy = sy - y0;
    const a = map.pixels[(y0 * map.width + x0) * 4 + channel];
    const b = map.pixels[(y0 * map.width + x1) * 4 + channel];
    const c = map.pixels[(y1 * map.width + x0) * 4 + channel];
    const d = map.pixels[(y1 * map.width + x1) * 4 + channel];
    return (a + (b - a) * dx) * (1 - dy) + (c + (d - c) * dx) * dy;
  }

  function mount(dial, { inside = false } = {}) {
    if (!dial || mounted.has(dial)) return;
    const rim = document.createElement("canvas");
    rim.className = "glass-rim";
    rim.setAttribute("aria-hidden", "true");
    const lens = document.createElement("canvas");
    lens.className = "glass-refraction";
    lens.setAttribute("aria-hidden", "true");
    const context = rim.getContext("2d");
    const lensContext = lens.getContext("2d");
    if (!context || !lensContext) return; // CSS keeps the edge without canvas.
    (inside ? dial : dial.parentElement).append(lens, rim);

    let previousSize = "";
    let pending = 0;
    const moving = new Set();

    function draw() {
      pending = 0;
      // Layout dimensions avoid redrawing a pressed button at its scaled size.
      const { width, height } = getComputedStyle(dial);
      const w = parseFloat(width);
      const h = parseFloat(height);
      if (w < 2 || h < 2) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const pixelsX = Math.round(w * dpr);
      const pixelsY = Math.round(h * dpr);
      const map = backdrop();
      const rect = dial.getBoundingClientRect();
      const bg = wallpaper?.getBoundingClientRect();
      // Match the independent axes of the wallpaper's object-fit: fill.
      const scaleX = map ? bg.width / map.width : 1;
      const scaleY = map ? bg.height / map.height : 1;
      const key = `${pixelsX}:${pixelsY}:${w}:${h}:${rect.left}:${rect.top}:${bg?.width}:${bg?.height}:${map?.source}`;
      if (key === previousSize) {
        if (moving.size) schedule();
        return;
      }
      previousSize = key;
      rim.width = pixelsX;
      rim.height = pixelsY;
      lens.width = pixelsX;
      lens.height = pixelsY;
      const image = context.createImageData(pixelsX, pixelsY);
      const lensImage = lensContext.createImageData(pixelsX, pixelsY);
      const size = Math.min(w, h);
      const radius = size / 2;
      const spineX = w / 2 - radius;
      const spineY = h / 2 - radius;
      const edgeWidth = inside ? Math.min(11, size * 0.23) : Math.min(18, size * 0.075);
      // Refraction covers the face; keep the specular edge narrow and separate.
      const refractionWidth = radius * (inside ? 0.96 : 0.72);
      const light = -Math.PI * 0.75;

      for (let y = 0; y < pixelsY; y++) {
        for (let x = 0; x < pixelsX; x++) {
          const px = (x + 0.5) / dpr - w / 2;
          const py = (y + 0.5) / dpr - h / 2;
          // Distance to the capsule's spine also gives the circle when w = h.
          const nx = px - clamp(px, -spineX, spineX);
          const ny = py - clamp(py, -spineY, spineY);
          const depth = radius - Math.hypot(nx, ny);
          if (depth < 0 || depth > Math.max(refractionWidth, edgeWidth * 2)) continue;
          const angle = Math.atan2(ny, nx);
          // Two opposing glints follow the surface normal; the center is clear.
          const facing = Math.cos(angle - light);
          const glare = Math.pow(Math.abs(facing), 6) * (facing > 0 ? 1 : 0.8);
          const edge = Math.exp(-depth / 1.15);
          // Bend the static wallpaper along the rounded surface normal.
          const ratio = clamp(1 - depth / refractionWidth);
          const incident = Math.asin(Math.pow(ratio, 0.7));
          const transmitted = Math.asin(Math.sin(incident) / 1.65);
          const refracted = clamp(Math.tan(incident - transmitted));
          const inner = Math.exp(-Math.pow((depth - edgeWidth * 0.22) / (edgeWidth * 0.16), 2));
          const shoulder = Math.exp(-Math.pow((depth - edgeWidth * 0.75) / (edgeWidth * 0.44), 2));
          const shade = edge * 0.19 + inner * (0.21 - glare * 0.14) * (0.8 + refracted * 0.2) + shoulder * 0.018;
          const highlight = Math.exp(-Math.pow((depth - 1.45) / 0.82, 2)) * (0.28 + glare * 0.7);
          const alpha = (highlight + shade * (1 - highlight)) * clamp(depth * dpr);
          const i = (y * pixelsX + x) * 4;
          const color = alpha > 0 ? (255 * highlight + 92 * shade * (1 - highlight)) / (highlight + shade * (1 - highlight)) : 255;
          let lensAlpha = 0;
          let sourceX = 0;
          let sourceY = 0;
          let normalX = 0;
          let normalY = 0;
          if (map && depth < refractionWidth) {
            const normalLength = Math.hypot(nx, ny) || 1;
            normalX = nx / normalLength;
            normalY = ny / normalLength;
            const shift = refracted * (inside ? 60 : 44);
            sourceX = (rect.left + px + w / 2 - normalX * shift - bg.left) / scaleX;
            sourceY = (rect.top + py + h / 2 - normalY * shift - bg.top) / scaleY;
            const fade = clamp((refractionWidth - depth) / (refractionWidth * 0.3));
            lensAlpha = fade * fade * (3 - 2 * fade) * 0.94 * clamp(depth * dpr);
          }
          image.data[i] = image.data[i + 1] = image.data[i + 2] = color;
          image.data[i + 3] = alpha * 255;
          for (let channel = 0; channel < 3; channel++) {
            // A slight channel spread makes edge refraction visible without tinting labels.
            const dispersion = (channel - 1) * refracted * 1.4;
            const base = lensAlpha ? sample(map, sourceX + normalX * dispersion / scaleX, sourceY + normalY * dispersion / scaleY, channel) : 0;
            lensImage.data[i + channel] = base;
          }
          lensImage.data[i + 3] = lensAlpha * 255;
        }
      }
      lensContext.putImageData(lensImage, 0, 0);
      context.putImageData(image, 0, 0);
      dial.classList.add("glass-ready");
      if (moving.size) schedule();
    }

    function schedule() {
      if (!pending) pending = requestAnimationFrame(draw);
    }
    listen(dial, "transitionrun", (event) => {
      if (event.target !== dial || !["left", "width"].includes(event.propertyName)) return;
      moving.add(event.propertyName);
      schedule();
    });
    for (const name of ["transitionend", "transitioncancel"]) {
      listen(dial, name, (event) => {
        if (event.target !== dial) return;
        moving.delete(event.propertyName);
        schedule();
      });
    }
    redraws.add(schedule);
    const observer = new ResizeObserver(schedule);
    observer.observe(dial);
    listen(window, "resize", schedule);
    draw();
    mounted.set(dial, { observer, lens, rim });
    cleanups.push(() => {
      observer.disconnect();
      cancelAnimationFrame(pending);
      lens.remove();
      rim.remove();
      dial.classList.remove("glass-ready");
      mounted.delete(dial);
    });
  }

  return { mount, destroy() {
    listeners.abort();
    cleanups.forEach((cleanup) => cleanup());
    redraws.clear();
    texture = null;
  } };
}
