import T from "./i18n.js";
import { createGlassFX } from "./glass.js";

export function initializeTimer() {
const cleanups = [];
const frames = new Set();
const delays = new Set();
const listeners = new AbortController();
function listen(target, name, callback) {
  target.addEventListener(name, callback, { signal: listeners.signal });
}
function requestFrame(callback) {
  const id = requestAnimationFrame((time) => { frames.delete(id); callback(time); });
  frames.add(id);
  return id;
}
function delay(callback, duration) {
  const id = setTimeout(() => { delays.delete(id); callback(); }, duration);
  delays.add(id);
  return id;
}
const timeEl = document.getElementById("time");
const sweepEl = document.getElementById("sweep");
const toggleBtn = document.getElementById("toggle");
const resetBtn = document.getElementById("reset");
const iconPause = document.getElementById("icon-pause");
const iconPlay = document.getElementById("icon-play");
const seg = document.getElementById("seg");
const segThumb = document.getElementById("seg-thumb");
const lapsEl = document.getElementById("laps");
const lapBtn = document.getElementById("lap");

const sheet = document.getElementById("sheet");
const cancelBtn = document.getElementById("cancel");
const confirmBtn = document.getElementById("confirm");

document.documentElement.lang = T.lang;
document.title = T.title;
seg.setAttribute("aria-label", T.modeSwitch);
for (const btn of seg.querySelectorAll("button[data-mode]")) {
  btn.textContent = T.modes[btn.dataset.mode];
}
document.querySelector(".sheet-title").textContent = T.sheetTitle;
cancelBtn.textContent = T.cancel;
confirmBtn.textContent = T.start;
for (const el of document.querySelectorAll(".unit")) {
  el.textContent = T.units[el.dataset.unit];
}
resetBtn.setAttribute("aria-label", T.reset);
resetBtn.setAttribute("title", T.reset);
lapBtn.setAttribute("aria-label", T.lap);
lapBtn.setAttribute("title", T.lap);

const themeToggle = document.getElementById("theme-toggle");

function applyTheme(theme, remember = false) {
  const next = theme === "dark" ? "dark" : "light";
  document.documentElement.dataset.theme = next;
  const labels = T;
  const label = next === "dark" ? labels.lightMode : labels.darkMode;
  themeToggle.setAttribute("aria-label", label);
  themeToggle.setAttribute("title", label);
  document.querySelector('meta[name="theme-color"]').content = next === "dark" ? "#101522" : "#edf0f3";
  if (remember) {
    try { localStorage.setItem("minimal-timer-theme", next); } catch (_) {}
  }
}

listen(themeToggle, "click", () => {
  applyTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark", true);
});
applyTheme(document.documentElement.dataset.theme);

const timers = {
  countdown: { duration: 10 * 60 * 1000, remaining: 10 * 60 * 1000, running: false },
  stopwatch: { elapsed: 0, running: false, laps: [], lastLapTotal: 0 },
};

const MAX_LAPS = 20;

function renderLaps() {
  const sw = timers.stopwatch;
  lapsEl.innerHTML = "";
  for (const lap of sw.laps) {
    const row = document.createElement("div");
    row.className = "lap-row";
    const num = document.createElement("span");
    num.className = "lap-num";
    num.textContent = String(lap.n).padStart(2, "0");
    const interval = document.createElement("span");
    interval.className = "lap-interval";
    interval.textContent = format(lap.interval);
    const total = document.createElement("span");
    total.className = "lap-total";
    total.textContent = format(lap.total);
    row.append(num, interval, total);
    lapsEl.appendChild(row);
  }
  lapsEl.classList.toggle("has-items", sw.laps.length > 0);
  lapBtn.classList.toggle("disabled", sw.laps.length >= MAX_LAPS);
  lapsEl.scrollTop = 0;
}

listen(lapBtn, "click", () => {
  const sw = timers.stopwatch;
  if (mode !== "stopwatch" || !sw.running || sw.laps.length >= MAX_LAPS) return;
  const total = sw.elapsed;
  sw.laps.unshift({ n: sw.laps.length + 1, interval: total - sw.lastLapTotal, total });
  sw.lastLapTotal = total;
  renderLaps();
});

let mode = "countdown";
let lastTick = null;

function format(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  const two = (n) => String(n).padStart(2, "0");
  return hours > 0
    ? `${hours}:${two(minutes)}:${two(seconds)}`
    : `${two(minutes)}:${two(seconds)}`;
}

function currentRunning() {
  if (mode === "countdown") return timers.countdown.running;
  if (mode === "stopwatch") return timers.stopwatch.running;
  return true;
}

function syncControls() {
  const running = currentRunning();
  document.body.classList.toggle("paused", !running);
  iconPause.style.display = running ? "" : "none";
  iconPlay.style.display = running ? "none" : "";
  toggleBtn.setAttribute("aria-label", running ? T.pause : T.resume);
}

function setRunning(next) {
  if (mode === "countdown") {
    timers.countdown.running = next && timers.countdown.duration > 0;
  } else if (mode === "stopwatch") {
    timers.stopwatch.running = next;
  }
  syncControls();
}

function finish() {
  timeEl.classList.add("flash");
  delay(() => timeEl.classList.remove("flash"), 2000);
}

function syncDialSize() {
  document.documentElement.style.setProperty("--dial-size", `${seg.getBoundingClientRect().width}px`);
}

function setMode(next) {
  mode = next;
  document.body.dataset.mode = next;
  for (const btn of seg.querySelectorAll("button")) {
    btn.classList.toggle("active", btn.dataset.mode === next);
  }
  const activeBtn = seg.querySelector(`button[data-mode="${next}"]`);
  segThumb.style.left = `${activeBtn.offsetLeft}px`;
  segThumb.style.width = `${activeBtn.offsetWidth}px`;
  syncDialSize();
  syncControls();
}

listen(seg, "click", (event) => {
  const btn = event.target.closest("button[data-mode]");
  if (btn) setMode(btn.dataset.mode);
});

listen(window, "resize", () => setMode(mode));
const sizeObserver = new ResizeObserver(syncDialSize);
sizeObserver.observe(seg);
cleanups.push(() => sizeObserver.disconnect());

listen(toggleBtn, "click", () => setRunning(!currentRunning()));

listen(resetBtn, "click", () => {
  if (mode === "countdown") {
    timers.countdown.remaining = timers.countdown.duration;
    timers.countdown.running = false;
  } else if (mode === "stopwatch") {
    timers.stopwatch.elapsed = 0;
    timers.stopwatch.laps = [];
    timers.stopwatch.lastLapTotal = 0;
    renderLaps();
  }
  syncControls();
});

listen(window, "keydown", (event) => {
  if (event.target instanceof Element && event.target.closest("button, input, textarea, select, [contenteditable]")) return;
  if (
    event.code === "Space" &&
    mode !== "clock" &&
    !sheet.classList.contains("open")
  ) {
    event.preventDefault();
    setRunning(!currentRunning());
  }
});

function render(now) {
  if (lastTick === null) lastTick = now;
  const delta = now - lastTick;
  lastTick = now;

  const cd = timers.countdown;
  if (cd.running && cd.duration > 0) {
    cd.remaining = Math.max(0, cd.remaining - delta);
    if (cd.remaining === 0) {
      cd.running = false;
      if (mode === "countdown") {
        finish();
        syncControls();
      }
    }
  }

  const sw = timers.stopwatch;
  if (sw.running) sw.elapsed += delta;

  let text;
  let angle;
  if (mode === "clock") {
    const d = new Date();
    const two = (n) => String(n).padStart(2, "0");
    text = `${two(d.getHours())}:${two(d.getMinutes())}:${two(d.getSeconds())}`;
    angle = ((d.getSeconds() + d.getMilliseconds() / 1000) / 60) * 360;
  } else if (mode === "stopwatch") {
    text = format(sw.elapsed);
    angle = (((sw.elapsed / 1000) % 60) / 60) * 360;
  } else {
    text = format(cd.remaining);
    angle = cd.duration > 0 ? (cd.remaining / cd.duration) * 360 : 0;
  }

  timeEl.innerHTML = text.replaceAll(":", '<span class="colon">:</span>');
  sweepEl.style.setProperty("--angle", `${angle}deg`);
  requestFrame(render);
}

/* ---- iOS 滚轮选择器 ---- */

const ITEM_H = 44;
const LOOP_SETS = 3;

function createWheel(el, count, loop) {
  const list = document.createElement("div");
  list.className = "wheel-list";
  const sets = loop ? LOOP_SETS : 1;
  for (let s = 0; s < sets; s++) {
    for (let i = 0; i < count; i++) {
      const item = document.createElement("div");
      item.className = "wheel-item";
      item.textContent = String(i).padStart(2, "0");
      item.dataset.index = s * count + i;
      list.appendChild(item);
    }
  }
  el.appendChild(list);
  cleanups.push(() => list.remove());

  const setHeight = count * ITEM_H;
  let snapTimer = null;

  function selectedIndex() {
    return Math.round(el.scrollTop / ITEM_H);
  }

  function value() {
    return ((selectedIndex() % count) + count) % count;
  }

  function updateTransforms() {
    const center = el.scrollTop + el.clientHeight / 2;
    for (const item of list.children) {
      const itemCenter = item.offsetTop + ITEM_H / 2;
      const delta = (itemCenter - center) / ITEM_H;
      if (Math.abs(delta) > 3.5) {
        item.style.opacity = "0";
        continue;
      }
      item.style.transform = `rotateX(${delta * -22}deg)`;
      item.style.opacity = String(Math.max(0, 1 - Math.abs(delta) * 0.3));
    }
  }

  function recenter() {
    if (!loop) return;
    if (el.scrollTop < setHeight - setHeight / 2) {
      el.scrollTop += setHeight;
    } else if (el.scrollTop >= setHeight * 2 - setHeight / 2) {
      el.scrollTop -= setHeight;
    }
  }

  listen(el, "scroll", () => {
    updateTransforms();
    clearTimeout(snapTimer);
    snapTimer = delay(recenter, 90);
  });

  listen(list, "click", (event) => {
    const item = event.target.closest(".wheel-item");
    if (!item) return;
    el.scrollTo({ top: Number(item.dataset.index) * ITEM_H, behavior: "smooth" });
  });

  function setValue(v, animate = false) {
    const base = loop ? count : 0;
    el.scrollTo({ top: (base + v) * ITEM_H, behavior: animate ? "smooth" : "auto" });
    updateTransforms();
  }

  setValue(0);
  return { value, setValue };
}

const wheelH = createWheel(document.getElementById("wheel-h"), 24, false);
const wheelM = createWheel(document.getElementById("wheel-m"), 60, true);
const wheelS = createWheel(document.getElementById("wheel-s"), 60, true);

function openSheet() {
  const totalSeconds = Math.floor(timers.countdown.duration / 1000);
  wheelH.setValue(Math.floor(totalSeconds / 3600));
  wheelM.setValue(Math.floor((totalSeconds % 3600) / 60));
  wheelS.setValue(totalSeconds % 60);
  sheet.classList.add("open");
}

function closeSheet() {
  sheet.classList.remove("open");
}

listen(timeEl, "click", () => {
  if (mode === "countdown") openSheet();
});
listen(cancelBtn, "click", closeSheet);
listen(sheet, "click", (event) => {
  if (event.target === sheet) closeSheet();
});

listen(confirmBtn, "click", () => {
  const ms =
    (wheelH.value() * 3600 + wheelM.value() * 60 + wheelS.value()) * 1000;
  if (ms > 0) {
    timers.countdown.duration = ms;
    timers.countdown.remaining = ms;
    timers.countdown.running = true;
    syncControls();
  }
  closeSheet();
});

setMode("countdown");
renderLaps();
requestFrame(render);

{
  const GlassFX = createGlassFX();
  cleanups.push(() => GlassFX.destroy());
  requestFrame(() => {
    GlassFX.mount(document.querySelector(".dial"));
    document.querySelectorAll(".seg, .seg-thumb, .controls button, .theme-toggle").forEach((surface) => {
      GlassFX.mount(surface, { inside: true });
    });
  });
}

return () => {
  listeners.abort();
  frames.forEach(cancelAnimationFrame);
  delays.forEach(clearTimeout);
  cleanups.reverse().forEach((cleanup) => cleanup());
};
}
