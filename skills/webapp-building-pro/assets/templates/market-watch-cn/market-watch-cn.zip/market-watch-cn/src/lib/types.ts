export interface Stock { cd: string; nm: string; pre: number; price: number; chg: number
                         hist: number[]; watch: boolean; limit?: boolean }
export interface Idx { nm: string; pv: number; pre: number; chg: number }
export interface Hold { s: Stock; sh: number; cost: number }
export interface Move { cd: string; nm: string; t: string; up: boolean; txt: string; why: string }
