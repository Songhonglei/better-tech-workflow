import { useEffect, useRef, useState } from 'react'
import Kit from './lib/kit.js'
import { IDXS, SECTORS, TIMES, buildWalk, stocks } from './lib/market.js'
import Chart from './components/Chart'
import { Portfolio, WatchList } from './components/Left'
import Right from './components/Right'
import Ai from './components/Ai'
import type { Idx, Move, Stock } from './lib/types'

// 快讯排头：涨停在开盘那一刻必然是空的（初始涨跌幅上限只有 ±2%，够不到入选线），
// 拿一屏空白当门面不合适。涨停挪到最后，有货了标签上的角标会提示。
const RTABS: [string, string][] = [['news', '快讯'], ['move', '异动'], ['senti', '情绪'], ['limit', '涨停']]
const clock = () => new Date().toTimeString().slice(0, 8)

export default function App() {
  const [cur, setCur] = useState<Stock>(stocks[0])
  const [ltab, setLtab] = useState('watch')
  const [rtab, setRtab] = useState('news')
  const [now, setNow] = useState(clock)
  const [tick, setTick] = useState(0)
  const [idxOn, setIdxOn] = useState(0)

  const W = useRef(buildWalk(stocks[0]))
  const moves = useRef<Move[]>([])
  const themeSlot = useRef<HTMLSpanElement>(null)

  const pick = (s: Stock) => { W.current = buildWalk(s); setCur(s) }

  useEffect(() => { Kit.themeToggle(() => {}, themeSlot.current) }, [])

  /* ── 模拟推流 ────────────────────────────────────────────────────────── */
  useEffect(() => {
    const a = setInterval(() => {
      const d = new Date(), mins = d.getHours() * 60 + d.getMinutes()
      const inSession = (mins >= 570 && mins < 690) || (mins >= 780 && mins < 900)
      const w = W.current
      stocks.forEach((s: Stock) => {
        if (s.limit) return                // 封住的板不走价
        const j = (Math.random() - .5) * .0035
        s.price = +(s.price * (1 + j)).toFixed(2)
        s.chg = (s.price - s.pre) / s.pre * 100
        if (inSession && w.upto < TIMES.length && s === cur) {
          w.walk[w.upto] = s.price; w.avg[w.upto] = w.avg[w.upto - 1]
          w.vols[w.upto] = Math.round(800 + Math.random() * 3600)
          w.upto++
        }
      })
      IDXS.forEach((x: Idx) => { x.chg += (Math.random() - .5) * .06 })
      // 异动捕捉
      stocks.forEach((s: Stock) => {
        if (Math.abs(s.chg) > 3 && Math.random() < .12) {
          moves.current.push({ cd: s.cd, nm: s.nm, t: clock(), up: s.chg > 0,
            txt: (s.chg > 0 ? '+' : '') + s.chg.toFixed(2) + '%',
            why: s.chg > 0 ? '放量急拉,大单净流入占比升至 14%' : '快速跳水,跌破分时均价' })
          if (moves.current.length > 40) moves.current.shift()
        }
      })
      setTick(n => n + 1)
    }, 1600)
    const b = setInterval(() => setNow(clock()), 1000)
    return () => { clearInterval(a); clearInterval(b) }
  }, [cur])

  /* ── 分时图 / 板块 ───────────────────────────────────────────────────── */
  const mainOpt = () => {
    const s = cur, up = s.chg >= 0, { walk, avg, vols, upto } = W.current
    return {
      animation: false,
      grid: [{ left: 10, right: 62, top: 16, height: '56%' }, { left: 10, right: 62, top: '70%', height: '20%' }],
      xAxis: [
        { ...Kit.axis('category', { data: TIMES.slice(0, upto), boundaryGap: false, axisLabel: { interval: 59 } }), gridIndex: 0 },
        { ...Kit.axis('category', { data: TIMES.slice(0, upto), boundaryGap: false, axisLabel: { show: false } }), gridIndex: 1 },
      ],
      yAxis: [
        { ...Kit.axis('value', { scale: true, position: 'right', axisLabel: { formatter: (v: number) => v.toFixed(2) } }), gridIndex: 0 },
        { ...Kit.axis('value', { position: 'right', axisLabel: { formatter: (v: number) => Kit.compact(v) } }), gridIndex: 1 },
      ],
      series: [
        { name: '价格', type: 'line', data: walk.slice(0, upto), showSymbol: false, symbol: 'none',
          lineStyle: { width: 1.6, color: up ? Kit.css('pos') : Kit.css('neg') }, itemStyle: { color: up ? Kit.css('pos') : Kit.css('neg') },
          areaStyle: { color: up ? Kit.css('pos') : Kit.css('neg'), opacity: .07 },
          markLine: { symbol: 'none', silent: true, label: { show: true, formatter: '昨收', fontSize: 9, color: Kit.css('faint'), fontFamily: Kit.css('mono') },
            lineStyle: { type: [4, 4], color: Kit.css('faint'), width: 1 }, data: [{ yAxis: s.pre }] } },
        { name: '均价', type: 'line', data: avg.slice(0, upto), showSymbol: false, symbol: 'none',
          lineStyle: { width: 1, color: Kit.css('accent') }, itemStyle: { color: Kit.css('accent') } },
        { name: '量', type: 'bar', xAxisIndex: 1, yAxisIndex: 1, data: vols.slice(0, upto).map((v: number, i: number) => ({
          value: v, itemStyle: { color: i && walk[i] < walk[i - 1] ? Kit.css('neg') : Kit.css('pos'), opacity: .55 } })), barWidth: '62%' },
      ],
    }
  }
  const sectorOpt = () => {
    const data = [...SECTORS].sort((a: [string, number], b: [string, number]) => a[1] - b[1])
    return {
      grid: { left: 8, right: 44, top: 6, bottom: 4, containLabel: true },
      xAxis: Kit.axis('value', { axisLabel: { formatter: (v: number) => v } }),
      yAxis: Kit.axis('category', { data: data.map((d: [string, number]) => d[0]), axisLabel: { color: Kit.css('muted'), fontSize: 11 } }),
      series: [{ type: 'bar', barWidth: '56%', data: data.map((d: [string, number]) => ({ value: d[1],
        itemStyle: { color: d[1] >= 0 ? Kit.css('pos') : Kit.css('neg'), opacity: .88 } })),
        label: { show: true, position: 'right', fontFamily: Kit.css('mono'), fontSize: 10,
          formatter: (p: { value: number }) => (p.value > 0 ? '+' : '') + p.value, color: Kit.css('muted') } }],
    }
  }

  const { walk, upto } = W.current
  const hi = Math.max(...walk.slice(0, upto)), lo = Math.min(...walk.slice(0, upto))
  const limitN = stocks.filter((s: Stock) => s.chg >= 9.9).length
  const watchN = stocks.filter((s: Stock) => s.watch).length

  const addWatch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const q = e.target.value.trim().toUpperCase()
    if (!q) return
    const hit = stocks.find((s: Stock) => !s.watch && (s.cd.includes(q) || s.nm.includes(q)))
    if (hit) { hit.watch = true; setTick(n => n + 1); Kit.toast('已加自选 · ' + hit.nm) }
    else Kit.toast('股票池未收录(演示池仅 20 支)')
    e.target.value = ''
  }

  return (
    <>
      <header>
        <div className="htop">
          <div className="logo">盘面<small>CN MARKET WATCH</small></div>
          <div id="idxbar" style={{ display: 'flex', gap: '8px' }}>
            {IDXS.map((x: Idx, i: number) => {
              const pv = +(x.pre * (1 + x.chg / 100)).toFixed(2)
              return (
                <div className={'idx' + (i === idxOn ? ' on' : '')} key={x.nm}
                     onClick={() => { setIdxOn(i); Kit.toast('指数详情为演示占位') }}>
                  <span className="nm">{x.nm}</span>
                  <span className={'pv ' + (x.chg >= 0 ? 'up' : 'dn')}>{pv}</span>
                  <span className={'pc ' + (x.chg >= 0 ? 'up' : 'dn')}>
                    {(x.chg >= 0 ? '+' : '') + x.chg.toFixed(2) + '%'}</span>
                </div>
              )
            })}
          </div>
          <span className="demo-note">数据为虚拟示例</span>
          <div className="spacer" />
          <span className="clock"><b id="clock">{now}</b> CST</span>
          <span id="theme-slot" ref={themeSlot} />
        </div>
      </header>

      <div className="tape" data-e2e="noop"><div className="lane" id="lane">
        {[0, 1].flatMap(k => stocks.map((s: Stock) => (
          <span className="tk" data-cd={s.cd} key={k + s.cd} onClick={() => pick(s)}>
            <span className="nm">{s.nm}</span>
            <span className={s.chg >= 0 ? 'up' : 'dn'}>{s.price.toFixed(2)}</span>
            <span className={s.chg >= 0 ? 'up' : 'dn'}>{(s.chg >= 0 ? '+' : '') + s.chg.toFixed(2) + '%'}</span>
          </span>
        )))}
      </div></div>

      <div className="app">
        <aside className="col l">
          <div className="wtabs">
            <button data-v="watch" className={ltab === 'watch' ? 'on' : undefined}
                    onClick={() => setLtab('watch')}>自选股</button>
            <button data-v="hold" className={ltab === 'hold' ? 'on' : undefined}
                    onClick={() => { setLtab('hold') }}>持仓</button>
            <span className="tail" id="w-count">{watchN + ' / ' + stocks.length}</span>
          </div>
          <div className="wsearch" id="wsearch" hidden={ltab !== 'watch'}>
            <input type="search" id="wq" placeholder="添加自选:代码或拼音首字母" onChange={addWatch} />
          </div>
          <WatchList cur={cur} tick={tick} hidden={ltab !== 'watch'} onPick={pick} />
          <Portfolio cur={cur} hidden={ltab !== 'hold'} onPick={pick} />
        </aside>

        <main className="center">
          <section>
            <div className="chead">
              <span className="stk" id="c-nm">{`${cur.nm} ${cur.cd}`}</span>
              <span className={'big ' + (cur.chg >= 0 ? 'up' : 'dn')} id="c-pv">{cur.price.toFixed(2)}</span>
              <span className={'chg ' + (cur.chg >= 0 ? 'up' : 'dn')} id="c-chg">
                {`${cur.chg >= 0 ? '+' : ''}${cur.chg.toFixed(2)}%  ${cur.chg >= 0 ? '+' : ''}${(cur.price - cur.pre).toFixed(2)}`}</span>
              <span className="oh">
                <span id="c-oh">{`开 ${walk[0].toFixed(2)}  高 ${hi.toFixed(2)}  低 ${lo.toFixed(2)}`}</span>
                <span>昨收 <b id="c-pre">{cur.pre.toFixed(2)}</b></span>
              </span>
            </div>
            <Chart id="c-main" className="cbody" build={mainOpt} deps={[cur, tick]} />
          </section>
          <section>
            <div className="ph"><h2>板块资金流</h2><span className="tail">主力净流入 · 亿元</span></div>
            <Chart id="c-sector" className="cbody" build={sectorOpt} />
          </section>
        </main>

        <aside className="col r">
          <div className="rtabs" id="rtabs">
            {RTABS.map(([v, t]) => (
              <button key={v} data-v={v} className={rtab === v ? 'on' : undefined} onClick={() => setRtab(v)}>
                {t}{v === 'limit' ? <> <span id="n-limit">{limitN || ''}</span></> : null}
              </button>
            ))}
          </div>
          <div className="rlist" id="rlist">
            <Right tab={rtab} moves={moves.current} onPick={pick} />
          </div>
          <Ai cur={cur} />
        </aside>
      </div>
    </>
  )
}
