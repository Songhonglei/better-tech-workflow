import { useEffect, useRef } from 'react'
import Kit from '../lib/kit.js'
import { HOLD, pnlOf, stocks } from '../lib/market.js'
import type { Hold, Stock } from '../lib/types'

/* 报价格子只换文字、不重排 —— 换行会把闪一下的动画打断，也会让正在看的那一行跳走。
   涨跌的那一下闪光是加个类再强制重排触发的，这一段必须直接对 DOM 做。 */
export function WatchList({ cur, tick, hidden, onPick }: {
  cur: Stock; tick: number; hidden: boolean; onPick: (s: Stock) => void
}) {
  const box = useRef<HTMLDivElement>(null)
  const last = useRef<Record<string, number>>({})
  const list: Stock[] = stocks.filter((s: Stock) => s.watch)

  useEffect(() => {
    box.current?.querySelectorAll<HTMLElement>('.wrow').forEach(row => {
      const s = stocks.find((x: Stock) => x.cd === row.dataset.cd)
      if (!s) return
      const pv = row.querySelector<HTMLElement>('[data-pv]')!
      const old = last.current[s.cd]
      last.current[s.cd] = s.price
      if (old === undefined || s.price === old) return
      pv.classList.remove('flash-u', 'flash-d')
      void pv.offsetWidth
      pv.classList.add(s.price > old ? 'flash-u' : 'flash-d')
    })
  }, [tick])

  return (
    <div className="wlist" id="wlist" hidden={hidden} ref={box}>
      {list.map(s => (
        <div className={'wrow' + (s === cur ? ' on' : '')} data-cd={s.cd} key={s.cd}
             onClick={() => onPick(s)}>
          <span className="nm">{s.nm}</span>
          <span className="pv" data-pv="">{s.price.toFixed(2)}</span>
          <span className="cd">{s.cd}</span>
          <span className={'pc ' + (s.chg >= 0 ? 'up' : 'dn')} data-pc="">
            {(s.chg >= 0 ? '+' : '') + s.chg.toFixed(2) + '%'}</span>
        </div>
      ))}
    </div>
  )
}

/* 组合当日净值曲线:以持仓股同步走出的确定性随机游走收尾于当前浮盈 */
function sparkPath(dayPc: number) {
  const r = Kit.rng(4096), N = 60
  let acc = 0; const pts: number[] = []
  for (let i = 0; i < N; i++) { acc += (r() - .5) * .18; pts.push(acc) }
  pts.push(pts[N - 1])
  for (let i = 0; i < N; i++) pts[i] += (dayPc - pts[N - 1]) * Math.pow(i / (N - 1), 1.6)
  const mn = Math.min(...pts), mx = Math.max(...pts), sp = Math.max(.01, mx - mn)
  return {
    path: pts.map((v, i) => `${(i / (N - 1) * 240).toFixed(1)},${(40 - (v - mn) / sp * 36).toFixed(1)}`).join(' '),
    zero: (40 - (0 - mn) / sp * 36).toFixed(1),
  }
}

/* 一进来就把持仓算好，第一眼三个读数就有值 —— 不等切到「持仓」那一下才算，
   否则首屏这里是一排破折号。 */
export function Portfolio({ cur, hidden, onPick }: {
  cur: Stock; hidden: boolean; onPick: (s: Stock) => void
}) {
  const tot = HOLD.reduce((a: number, h: Hold) => a + h.s.price * h.sh, 0)
  const day = HOLD.reduce((a: number, h: Hold) => a + (h.s.price - h.s.pre) * h.sh, 0)
  const pnl = HOLD.reduce((a: number, h: Hold) => a + pnlOf(h), 0)
  const costSum = HOLD.reduce((a: number, h: Hold) => a + h.cost * h.sh, 0)
  const dayPc = day / (tot - day) * 100
  const { path, zero } = sparkPath(dayPc)
  return (
    <div className="pview" id="pview" hidden={hidden}>
      <div className="psum">
        <div className="t"><span>总市值</span>
          <b id="p-total">{Kit.fmt(Math.round(tot))}<small>元</small></b></div>
        <div className="t"><span>当日盈亏</span>
          <b id="p-day" className={day >= 0 ? 'up' : 'dn'}>
            {(day >= 0 ? '+' : '') + Kit.fmt(Math.round(day))}<small>{dayPc.toFixed(2) + '%'}</small></b></div>
        <div className="t"><span>持仓收益</span>
          <b id="p-pnl" className={pnl >= 0 ? 'up' : 'dn'}>
            {(pnl >= 0 ? '+' : '') + Kit.fmt(Math.round(pnl))}<small>{(pnl / costSum * 100).toFixed(1) + '%'}</small></b></div>
        <svg className="spark" id="p-spark" viewBox="0 0 240 44" preserveAspectRatio="none">
          <line x1="0" y1={zero} x2="240" y2={zero} stroke="var(--faint)" strokeWidth=".6" strokeDasharray="3 3" />
          <polygon points={`0,44 ${path} 240,44`} fill="var(--accent)" opacity=".08" />
          <polyline points={path} fill="none" stroke={dayPc >= 0 ? 'var(--pos)' : 'var(--neg)'}
                    strokeWidth="1.4" vectorEffect="non-scaling-stroke" />
        </svg>
      </div>
      <div id="prows">
        {HOLD.map((h: Hold) => {
          const p = pnlOf(h), pc = (h.s.price - h.cost) / h.cost * 100
          return (
            <div className={'prow' + (h.s === cur ? ' on' : '')} key={h.s.cd} onClick={() => onPick(h.s)}>
              <span className="nm">{h.s.nm}</span>
              <span className={'pnl ' + (p >= 0 ? 'up' : 'dn')}>
                {(p >= 0 ? '+' : '') + Kit.fmt(Math.round(p))}</span>
              <span className="sub">
                {`${h.sh} 股 · 成本 ${h.cost.toFixed(2)} · 现 ${h.s.price.toFixed(2)} · ${pc >= 0 ? '+' : ''}${pc.toFixed(1)}%`}</span>
            </div>
          )
        })}
      </div>
    </div>
  )
}
