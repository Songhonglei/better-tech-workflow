import { useEffect, useRef, useState } from 'react'
import Orb from '../lib/orb.js'
import { AI } from '../lib/market.js'
import type { Stock } from '../lib/types'

const CHIPS: [string, string][] = [['brief', '早盘综述'], ['move', '异动解读'], ['risk', '风险提示']]

/* 打字机是一段自己往 DOM 里写的动画，插入符要跟着最后一个字走 —— 交给 React 逐帧
   重渲染既没必要也更贵，这里让它直接写。 */
export default function Ai({ cur }: { cur: Stock }) {
  const [mode, setMode] = useState('brief')
  const [gen, setGen] = useState(0)
  const box = useRef<HTMLDivElement>(null)
  const orbHost = useRef<HTMLSpanElement>(null)
  const orb = useRef<{ setState: (s: string) => void; stop: () => void } | null>(null)
  const cell = useRef(cur); cell.current = cur

  useEffect(() => {
    orb.current = Orb.mount(orbHost.current, { state: 'orbit', size: 16 })
    return () => { orb.current?.stop(); orb.current = null }
  }, [])

  useEffect(() => {
    const pool = AI[mode]
    const text: string = pool[Math.floor(Math.random() * pool.length)](cell.current)
    const el = box.current!
    el.innerHTML = '<span class="caret"></span>'
    orb.current?.setState('scan')          // 子午线扫过点阵球 = 思考中
    let t = 0
    const delay = setTimeout(() => {
      orb.current?.setState('orbit')
      let i = 0
      ;(function step() {
        i += 2 + Math.floor(Math.random() * 3)
        el.innerHTML = text.slice(0, i) + '<span class="caret"></span>'
        if (i < text.length) t = setTimeout(step, 18 + Math.random() * 30) as unknown as number
      })()
    }, 900)
    return () => { clearTimeout(delay); clearTimeout(t) }
  }, [mode, gen])

  return (
    <div className="ai">
      <div className="hd"><span className="orb" id="ai-orb" ref={orbHost} /><b>AI 盘面解读</b>
        <span className="tag">DEMO · 示例分析</span></div>
      <div className="chips" id="ai-chips">
        {CHIPS.map(([v, t]) => (
          <button key={v} className={'chip' + (mode === v ? ' on' : '')} data-v={v}
                  onClick={() => setMode(v)}>{t}</button>
        ))}
      </div>
      <div className="txt" id="ai-txt" ref={box} />
      <div className="ft">
        <button className="btn" id="ai-regen" onClick={() => setGen(n => n + 1)}>重新生成</button>
        <span className="note">非投资建议 · 数据为模拟推流</span>
      </div>
    </div>
  )
}
