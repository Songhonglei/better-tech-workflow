import Kit from '../lib/kit.js'
import { NEWS, R, TIMES, stocks } from '../lib/market.js'
import type { Move, Stock } from '../lib/types'

export default function Right({ tab, moves, onPick }: {
  tab: string; moves: Move[]; onPick: (s: Stock) => void
}) {
  if (tab === 'limit') {
    const ups: Stock[] = stocks.filter((s: Stock) => s.chg >= 9.9)
      .concat(stocks.filter((s: Stock) => s.chg >= 4 && s.chg < 9.9).slice(0, 6))
    return (
      <>
        {ups.map(s => (
          <div className="mrow" key={s.cd} onClick={() => onPick(s)}>
            <span className="nm">{s.nm}</span><span className="pv">{s.price.toFixed(2)}</span>
            <span className="pc up">{'+' + s.chg.toFixed(2) + '%'}</span>
            <span className="why">{s.chg >= 9.9
              ? '封单 ' + (Math.round(R() * 8) + 2) + '.' + Math.round(R() * 9) + ' 亿 · 首次触板 ' + TIMES[Math.round(R() * 120)]
              : '跟随板块走强,量能温和放大'}</span>
          </div>
        ))}
      </>
    )
  }
  if (tab === 'move') {
    if (!moves.length) return (
      <div className="mrow"><span className="nm" style={{ color: 'var(--faint)' }}>等待盘中异动…</span></div>
    )
    return (
      <>
        {moves.slice(-14).reverse().map((m, i) => (
          <div className="mrow" key={m.cd + m.t + i} onClick={() => {
            const s = stocks.find((x: Stock) => x.cd === m.cd); if (s) onPick(s)
          }}>
            <span className="nm">{m.nm}</span><span className="pv">{m.t}</span>
            <span className={'pc ' + (m.up ? 'up' : 'dn')}>{m.txt}</span>
            <span className="why">{m.why}</span>
          </div>
        ))}
      </>
    )
  }
  if (tab === 'news') {
    return (
      <>
        {NEWS.map(([t, src, hl]: string[], i: number) => (
          <div className="nrow" key={i} onClick={() => Kit.toast('快讯详情为演示占位')}>
            <span className="tm">{t}</span><span className="src">{src}</span>
            <span className="hl" dangerouslySetInnerHTML={{ __html: hl }} />
          </div>
        ))}
      </>
    )
  }
  const upN = stocks.filter((s: Stock) => s.chg > 0).length, dnN = stocks.length - upN
  const limitN = stocks.filter((s: Stock) => s.chg >= 9.9).length
  const items: [string, number, string][] = [
    ['涨跌家数', upN / stocks.length * 100, `${upN} / ${dnN}`],
    ['涨停强度', Math.min(100, limitN * 18), `${limitN} 家`],
    ['炸板率', 22 + R() * 10, '24.6%'],
    ['北向净流入', 58 + R() * 8, '+42.8 亿'],
    ['两市成交', 76 + R() * 6, '9,864 亿'],
  ]
  return (
    <div className="sentis">
      {items.map(([lb, pc, vl]) => (
        <div className="srow" key={lb}>
          <span className="lb">{lb}</span>
          <div className="track"><i style={{ width: pc + '%' }} /></div>
          <span className="vl">{vl}</span>
        </div>
      ))}
    </div>
  )
}
