import Kit from '../lib/kit.js'
import { PER, matches, money, orders, statusClass, statusLabel } from '../lib/data.js'
import type { Order } from '../lib/types'

export function ordersFor(filt: string, cityFilt: string | null, query: string): Order[] {
  return orders.filter((o: Order) => (filt === 'all' || o.status === filt)
    && (!cityFilt || o.city === cityFilt) && matches(o, query))
}

/* 地图是导航件：选中后必须留一个可见、可清除的凭据，否则用户会以为表坏了。 */
export function GeoChip({ city, onClear }: { city: string | null; onClear: () => void }) {
  return (
    <span id="geoChip">
      {city && (
        <button className="geochip" id="geoClear" onClick={onClear}>
          {city + '\n         '}
          <b>{orders.filter((o: Order) => o.city === city).length}</b><u>×</u>
        </button>
      )}
    </span>
  )
}

export function OrderRows({ rows, cityFilt, query, market }: {
  rows: Order[]; cityFilt: string | null; query: string; market: boolean
}) {
  const cols = market ? 6 : 5
  if (!rows.length) return (
    <tr><td colSpan={cols} className="empty">
      {'没有匹配的订单：' + (cityFilt ? '“' + cityFilt + '”' : '“' + query + '”')}</td></tr>
  )
  return (
    <>
      {rows.map(o => (
        <tr key={o.id}>
          <td className="num">{o.id}</td>
          <td><div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div className="av">{o.initials}</div>{o.customer}</div></td>
          {market && <td className="dim">{o.city}</td>}
          <td className="num dim">{o.date}</td>
          <td><span className={'status ' + statusClass(o.status)}>{statusLabel(o.status)}</span></td>
          <td className="n num">{money(o.total)}</td>
        </tr>
      ))}
    </>
  )
}

export function Pager({ total, page, onPage }: {
  total: number; page: number; onPage: (p: number) => void
}) {
  const pages = Math.max(1, Math.ceil(total / PER))
  return (
    <div className="tfoot">
      <span id="pgInfo">
        {total ? `${(page - 1) * PER + 1}–${Math.min(page * PER, total)} / 共 ${total}` : '0 条结果'}</span>
      <span className="pg" id="pg">
        {Array.from({ length: pages }, (_, i) => (
          <button key={i} className={i + 1 === page ? 'on' : ''} data-p={i + 1}
                  onClick={() => onPage(i + 1)}>{i + 1}</button>
        ))}
      </span>
    </div>
  )
}

export function exportOrders(rows: Order[]) {
  Kit.download('orders.csv', Kit.toCSV([['id', 'customer', 'date', 'status', 'total'],
    ...rows.map(o => [o.id, o.customer, o.date, o.status, o.total])]))
  Kit.toast('已导出 ' + rows.length + ' 笔订单')
}
