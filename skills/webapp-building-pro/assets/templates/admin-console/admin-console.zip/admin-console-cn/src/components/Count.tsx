import { useEffect, useRef } from 'react'
import Kit from '../lib/kit.js'

/* Kit.count animates the digits straight into the node, so React hands it an
   element and stays out of the way. */
export default function Count({ id, to, d = 0, prefix = '', suffix = '', className = 'val' }: {
  id?: string; to: number; d?: number; prefix?: string; suffix?: string; className?: string
}) {
  const el = useRef<HTMLDivElement>(null)
  useEffect(() => { Kit.count(el.current, to, { d, prefix, suffix }) }, [to])
  return <div className={className} id={id} ref={el}>—</div>
}
