import { useEffect, useRef, useState } from 'react'
import Kit from '../lib/kit.js'
import { C, EVENTS, PER, SRC, marketLoad, ramp, revOpt, rnd } from '../lib/data.js'
import { worldmap } from '../lib/worldmap.js'
import Panel from '../components/Panel'
import Seg from '../components/Seg'
import Chart from '../components/Chart'
import Count from '../components/Count'
import { GeoChip, OrderRows, Pager, ordersFor } from './Orders'

const KPI = [
  { lbl: '收入', to: 284310, d: +12.4, money: true },
  { lbl: '订单', to: 3842, d: +6.1 },
  { lbl: '活跃用户', to: 18204, d: +3.8 },
  { lbl: '退款率', to: 2.1, d: -0.4, pct: true, goodDown: true },
]
/* 迷你走势的 24 个点在模块里一次抽好：它们和 sample data 共用同一条随机序列，
   放进组件会随重渲染继续抽，数字每切一次视图就变一次。 */
const SPARKS = KPI.map(() => {
  let v = 50 + rnd() * 20
  return Array.from({ length: 24 }, () => (v += (rnd() - .45) * 9, Math.max(8, v)))
})

export default function Dashboard({ filt, setFilt, page, setPage, cityFilt, setCityFilt, query }: {
  filt: string; setFilt: (v: string) => void
  page: number; setPage: (p: number) => void
  cityFilt: string | null; setCityFilt: (c: string | null) => void
  query: string
}) {
  const [revDays, setRevDays] = useState(30)
  const mapwrap = useRef<HTMLDivElement>(null)
  const table = useRef<HTMLTableElement>(null)
  const bars = useRef<HTMLDivElement>(null)
  const cityRef = useRef(cityFilt); cityRef.current = cityFilt

  /* 世界地图是一台自己管画布的部件，只在挂载时建一次，热点随筛选推进去。 */
  const map = useRef<{ setHotspots: (h: unknown[]) => void; destroy: () => void } | null>(null)
  useEffect(() => {
    let dead = false
    worldmap(mapwrap.current, {
      hotspots: marketLoad(cityRef.current),
      routes: [['上海', '罗马'], ['北京', '马德里'], ['深圳', '悉尼'],
               ['杭州', '东京'], ['广州', '巴塞罗那'], ['成都', '新加坡'],
               ['上海', '洛杉矶'], ['纽约', '里斯本'], ['迪拜', '孟买'],
               ['圣保罗', '开普敦'], ['拉各斯', '卡萨布兰卡'], ['内罗毕', '迪拜'],
               ['利马', '墨西哥城'], ['雅加达', '马尼拉'], ['布宜诺斯艾利斯', '圣地亚哥']],
      onPick: (s: { city: string }) => {
        setCityFilt(cityRef.current === s.city ? null : s.city)
        setPage(1)
      },
    }).then((m: typeof map.current) => { if (dead) m?.destroy(); else map.current = m })
    return () => { dead = true; map.current?.destroy(); map.current = null }
  }, [])
  useEffect(() => { map.current?.setHotspots(marketLoad(cityFilt)) }, [cityFilt])

  useEffect(() => { Kit.sortable(table.current) }, [])
  // Bars grow from zero on the next frame so the width transition has something
  // to animate from; setting the final width inline would just paint it there.
  useEffect(() => {
    requestAnimationFrame(() => bars.current?.querySelectorAll<HTMLElement>('.track i').forEach(el => {
      el.style.background = ramp()[+el.dataset.c!]
      el.style.width = el.dataset.w + '%'
    }))
  }, [])

  const rows = ordersFor(filt, cityFilt, query)
  const pages = Math.max(1, Math.ceil(rows.length / PER))
  const pg = Math.min(page, pages)
  const slice = rows.slice((pg - 1) * PER, pg * PER)

  return (
    <>
      <div className="kpis">
        {KPI.map((k, i) => {
          const up = k.d >= 0, good = k.goodDown ? !up : up
          return (
            <div className="kpi" data-reveal="" key={k.lbl}>
              <div className="lbl">{k.lbl}</div>
              <Count id={'k' + i} to={k.to} d={k.pct ? 1 : 0}
                     prefix={k.money ? '¥' : ''} suffix={k.pct ? '%' : ''} />
              <div className={'delta ' + (good ? 'pos' : 'neg')}>
                {(up ? '↑' : '↓') + ' ' + Math.abs(k.d) + '%\n          '}
                <em>较上月</em></div>
              <Chart className="spark" id={'sp' + i} build={() => ({
                grid: { left: 1, right: 1, top: 3, bottom: 1 }, tooltip: { show: false },
                xAxis: { type: 'category', show: false, boundaryGap: false },
                yAxis: { type: 'value', show: false, scale: true },
                series: [{ type: 'line', data: SPARKS[i], smooth: .4, symbol: 'none',
                  lineStyle: { width: 1.3, color: C('accent') },
                  areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
                    { offset: 0, color: C('accent') + '2e' }, { offset: 1, color: C('accent') + '00' }] } } }],
              })} />
            </div>
          )
        })}
      </div>

      <Panel title="全球交易" tools={<>
        <span className="faint" style={{ fontSize: '11.5px' }}>点击城市筛选</span>
        <GeoChip city={cityFilt} onClear={() => { setCityFilt(null); setPage(1) }} />
      </>}>
        <div className="mapwrap" id="mapwrap" ref={mapwrap} />
        <div className="maplegend"><i />订单金额</div>
      </Panel>

      <div className="g2">
        <Panel title="收入" tools={<>
          <span className="faint" style={{ fontSize: '11.5px' }}>对比上期</span>
          <Seg id="rangeSeg" items={[['30', '30 天'], ['90', '90 天'], ['365', '12 月']]}
               onPick={v => setRevDays(+v)} />
        </>}>
          <Chart className="chart fill" id="revChart" build={() => revOpt(revDays)} deps={[revDays]} />
        </Panel>

        <Panel title="流量来源">
          <Chart className="chart" id="srcChart" style={{ height: '176px' }} build={() => ({
            tooltip: { trigger: 'item', valueFormatter: (v: number) => v + '%' },
            series: [{ type: 'pie', radius: ['62%', '84%'], center: ['50%', '52%'], avoidLabelOverlap: false,
              itemStyle: { borderColor: C('panel'), borderWidth: 2 },
              label: { show: true, position: 'center', formatter: '{a|18,204}\n{b|会话}', rich: {
                a: { fontSize: 20, fontWeight: 500, color: C('ink'), fontFamily: C('mono') },
                b: { fontSize: 11, color: C('faint'), padding: [5, 0, 0, 0] } } },
              emphasis: { label: { show: true }, scale: false },
              data: SRC.map(([n, v]: [string, number], i: number) => ({ name: n, value: v, itemStyle: { color: ramp()[i] } })) }],
          })} />
          <div className="bars" ref={bars}>
            {SRC.map(([n, v]: [string, number], i: number) => (
              <div className="bar" key={n}>
                <div className="r"><span>{n}</span><b>{v + '%'}</b></div>
                <div className="track"><i style={{ width: 0 }} data-w={v / SRC[0][1] * 100} data-c={i} /></div>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      <div className="g2">
        <Panel title="近期订单" tools={
          <Seg id="statSeg" items={[['all', '全部'], ['Paid', '已支付'], ['Pending', '待处理'], ['Refunded', '已退款']]}
               onPick={v => { setFilt(v); setPage(1) }} />}>
          <div style={{ overflowX: 'auto' }}><table id="ordTable" ref={table}>
            <thead><tr>
              <th data-sort="s">订单</th><th data-sort="s">客户</th>
              <th data-sort="s">城市</th><th data-sort="s">日期</th><th data-sort="s">状态</th>
              <th className="n" data-sort="n">总额</th>
            </tr></thead>
            <tbody id="ordBody">
              <OrderRows rows={slice} cityFilt={cityFilt} query={query} market />
            </tbody>
          </table></div>
          <Pager total={rows.length} page={pg} onPage={setPage} />
        </Panel>

        <Panel title="动态">
          <div className="feed">
            {EVENTS.map(([t, m, c, w]: string[]) => (
              <div className="ev" key={t}>
                <span className="d" style={{ background: `var(--${c})` }} />
                <div style={{ flex: 1 }}><div className="t">{t}</div><div className="m">{m}</div></div>
                <div className="w">{w}</div>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </>
  )
}
