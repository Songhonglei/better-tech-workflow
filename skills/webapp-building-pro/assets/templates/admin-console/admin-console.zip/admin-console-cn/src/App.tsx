import { Fragment, useEffect, useRef, useState } from 'react'
import Kit from './lib/kit.js'
import { aurora } from './lib/fx.js'
import { EVENTS, customers, invoices, orders, products } from './lib/data.js'
import Dashboard from './views/Dashboard'
import Analytics from './views/Analytics'
import Reports from './views/Reports'
import Customers from './views/Customers'
import OrdersView from './views/OrdersView'
import Products from './views/Products'
import Invoices from './views/Invoices'
import Settings from './views/Settings'

const ICONS: Record<string, React.ReactElement> = {
  dashboard: <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="9" rx="1.5" /><rect x="14" y="3" width="7" height="5" rx="1.5" /><rect x="14" y="12" width="7" height="9" rx="1.5" /><rect x="3" y="16" width="7" height="5" rx="1.5" /></svg>,
  analytics: <svg viewBox="0 0 24 24"><path d="M3 17l5-5 4 3 8-8" /><path d="M21 7h-5v5" /></svg>,
  reports: <svg viewBox="0 0 24 24"><path d="M9 17V9m4 8V5m4 12v-5" /><rect x="3" y="3" width="18" height="18" rx="2.5" /></svg>,
  customers: <svg viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 00-3-3.87" /></svg>,
  orders: <svg viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z" /><path d="M3 6h18M16 10a4 4 0 01-8 0" /></svg>,
  products: <svg viewBox="0 0 24 24"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-14L4 7m8 4v10M4 7v10l8 4" /></svg>,
  invoices: <svg viewBox="0 0 24 24"><rect x="2" y="5" width="20" height="14" rx="2" /><path d="M2 10h20" /></svg>,
  settings: <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06A1.65 1.65 0 004.6 15a1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06A1.65 1.65 0 009 4.6a1.65 1.65 0 001-1.51V3a2 2 0 114 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06A1.65 1.65 0 0019.4 9c.24.58.81.98 1.51 1H21a2 2 0 110 4h-.09c-.7.02-1.27.42-1.51 1z" /></svg>,
}

/* Every sidebar entry renders a real screen from the same dataset. The point
   is not eight decorations: a nav item that only swaps a heading feels dead. */
const VIEWS: Record<string, { title: string; crumb: string }> = {
  dashboard: { title: '总览', crumb: '4 分钟前更新' },
  analytics: { title: '分析', crumb: '获客与留存 · 最近 90 天' },
  reports: { title: '报表', crumb: '6 份已存报表 · 2 份定时任务' },
  customers: { title: '客户', crumb: customers.length + ' 个客户' },
  orders: { title: '订单', crumb: orders.length + ' 笔近 20 天订单' },
  products: { title: '商品', crumb: products.length + ' 个在售 SKU' },
  invoices: { title: '发票', crumb: invoices.length + ' 张发票 · 按未结天数分析' },
  settings: { title: '设置', crumb: '工作区偏好' },
}
const NAV: [string, string][][] = [
  [['dashboard', '总览'], ['analytics', '分析'], ['reports', '报表']],
  [['customers', '客户'], ['orders', '订单'], ['products', '商品'], ['invoices', '发票']],
  [['settings', '设置']],
]
const LABELS = ['概览', '管理', '系统']

export default function App() {
  const [current, setCurrent] = useState('dashboard')
  const [query, setQuery] = useState('')
  const [filt, setFilt] = useState('all')
  const [page, setPage] = useState(1)
  const [cityFilt, setCityFilt] = useState<string | null>(null)
  const [popOn, setPopOn] = useState(false)
  const [themeRev, setThemeRev] = useState(0)

  const glow = useRef<HTMLDivElement>(null)
  const pop = useRef<HTMLDivElement>(null)

  useEffect(() => { aurora(glow.current, { amp: .55, scale: 2.6 }) }, [])
  useEffect(() => {
    Kit.onTheme(() => setThemeRev(n => n + 1))
    const onDoc = (e: MouseEvent) => {
      if (!pop.current?.contains(e.target as Node)) setPopOn(false)
    }
    document.addEventListener('click', onDoc)
    return () => document.removeEventListener('click', onDoc)
  }, [])
  useEffect(() => { Kit.reveal('[data-reveal]') }, [current, query, themeRev])

  const v = VIEWS[current]
  const shared = { filt, setFilt, page, setPage, cityFilt, setCityFilt, query }
  /* 换主题时 settings 那屏要重建（分段控件要跟着新主题重设），用 key 逼一次重挂载。 */
  const body = current === 'dashboard' ? <Dashboard {...shared} />
    : current === 'analytics' ? <Analytics />
    : current === 'reports' ? <Reports />
    : current === 'customers' ? <Customers query={query} />
    : current === 'orders' ? <OrdersView {...shared} />
    : current === 'products' ? <Products query={query} />
    : current === 'invoices' ? <Invoices query={query} />
    : <Settings key={themeRev} />

  return (
    <>
      <div id="glow" ref={glow} />
      <div className="app">
        <aside>
          <div className="brand">
            <svg className="logo" viewBox="0 0 24 24" aria-hidden="true">
              <circle className="ring" cx="12" cy="12" r="10.4" />
              <path className="tick" d="M12 2.2v2.1M12 19.7v2.1M2.2 12h2.1M19.7 12h2.1" />
              <path className="n" d="M12 2.9 16.3 12 12 12Z" />
              <path className="n" d="M12 2.9 7.7 12 12 12Z" opacity=".55" />
              <path className="s" d="M7.7 12 12 21.1 16.3 12Z" />
            </svg>
            北风</div>
          <nav id="nav">
            {NAV.map((group, gi) => (
              <Fragment key={LABELS[gi]}>
                <div className="navlabel">{LABELS[gi]}</div>
                {group.map(([v2, label]) => (
                  <button key={v2} className={'navitem' + (current === v2 ? ' on' : '')} data-v={v2}
                          onClick={() => { setCurrent(v2) }}>
                    {ICONS[v2]}{label}
                    {v2 === 'orders' && <> <span className="badge" id="navOrders">12</span></>}
                  </button>
                ))}
              </Fragment>
            ))}
          </nav>
          <div className="who">
            <div className="av">林</div>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontWeight: 520, fontSize: '12.5px' }}>林安然</div>
              <div className="faint" style={{ fontSize: '11px' }}>运营负责人</div>
            </div>
          </div>
        </aside>

        <main>
          <header>
            <div><h1 id="title">{v.title}</h1><div className="crumb" id="crumb">{v.crumb}</div></div>
            <div className="spacer" />
            <div className="search">
              <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7" /><path d="M21 21l-4-4" /></svg>
              {/* Search filters whatever view is open rather than pretending to be global. */}
              <input id="q" type="search" placeholder="搜索订单、客户…"
                     onChange={e => { setQuery(e.target.value.trim().toLowerCase()); setPage(1) }} />
            </div>
            <button className="iconbtn" id="theme" title="切换明暗主题" aria-label="切换明暗主题"
                    onClick={() => Kit.toggle()}>
              <svg viewBox="0 0 24 24"><path d="M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z" /></svg>
            </button>
            <button className="iconbtn" id="bell" title="通知" aria-label="通知"
                    onClick={e => { e.stopPropagation(); setPopOn(o => !o) }}>
              <svg viewBox="0 0 24 24"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.7 21a2 2 0 01-3.4 0" /></svg>
              <span className="dot" />
            </button>
            <div className={'pop' + (popOn ? ' on' : '')} id="pop" ref={pop}>
              <div className="ph">通知 · 3 条未读</div>
              {EVENTS.slice(0, 5).map(([t, m, c, w]: string[]) => (
                <div className="pi" key={t}>
                  <span className="d" style={{ background: `var(--${c})` }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 500 }}>{t}</div>
                    <div className="faint" style={{ fontSize: '11.5px', marginTop: '1px' }}>{m}</div>
                  </div>
                  <span className="faint num" style={{ fontSize: '10.5px' }}>{w}</span>
                </div>
              ))}
            </div>
          </header>
          <div className="wrap" id="view">{body}</div>
        </main>
      </div>
    </>
  )
}
