import { useEffect, useRef } from 'react'
import Kit from '../lib/kit.js'

/* Kit.seg owns the sliding pill and the `on` class; React just supplies the
   buttons and takes the callback. */
export default function Seg({ id, items, value, onPick }: {
  id?: string
  items: [string, string][]
  value?: string
  onPick: (v: string) => void
}) {
  const box = useRef<HTMLSpanElement>(null)
  const cb = useRef(onPick); cb.current = onPick
  useEffect(() => {
    const set = Kit.seg(box.current, (v: string) => cb.current(v))
    if (value) set(value)
  }, [])
  return (
    <span className="seg" id={id} ref={box}>
      {items.map(([v, label], i) => (
        <button key={v} data-v={v} className={i === 0 ? 'on' : undefined}>{label}</button>
      ))}
    </span>
  )
}
