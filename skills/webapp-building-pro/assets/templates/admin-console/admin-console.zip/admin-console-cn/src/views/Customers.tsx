import { useEffect, useRef, useState } from 'react'
import Kit from '../lib/kit.js'
import { customers, matches, money, planLabel } from '../lib/data.js'
import Panel from '../components/Panel'
import Seg from '../components/Seg'
import type { Customer } from '../lib/types'

export default function Customers({ query }: { query: string }) {
  const [plan, setPlan] = useState('all')
  const table = useRef<HTMLTableElement>(null)
  useEffect(() => { Kit.sortable(table.current) }, [])
  const rows: Customer[] = customers.filter((c: Customer) =>
    (plan === 'all' || c.plan === plan) && matches(c, query))
  return (
    <Panel title="客户账户" tools={
      <Seg id="planSeg" items={[['all', '全部'], ['Starter', '入门版'], ['Business', '商业版'], ['Enterprise', '企业版']]}
           onPick={setPlan} />}>
      <div style={{ overflowX: 'auto' }}><table id="cTable" ref={table}>
        <thead><tr>
          <th data-sort="s">客户</th><th data-sort="s">套餐</th>
          <th className="n" data-sort="n">席位</th><th className="n" data-sort="n">月度经常性收入</th>
          <th className="n" data-sort="n">健康度</th><th className="n" data-sort="n">加入年份</th>
        </tr></thead>
        <tbody id="cBody">
          {!rows.length
            ? <tr><td colSpan={6} className="empty">{`没有匹配“${query}”的客户`}</td></tr>
            : rows.map((c, i) => (
              <tr key={c.name + i}>
                <td><div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <div className="av">{c.initials}</div>{c.name}</div></td>
                <td><span className={'tag ' + (c.plan === 'Enterprise' ? 'pos' : 'dim')}>{planLabel(c.plan)}</span></td>
                <td className="n num">{c.seats}</td><td className="n num">{money(c.mrr)}</td>
                <td className={'n num ' + (c.health < 60 ? 'neg' : c.health < 80 ? 'warn' : 'pos')}>{c.health}</td>
                <td className="n num dim">{c.since}</td>
              </tr>
            ))}
        </tbody>
      </table></div>
    </Panel>
  )
}
