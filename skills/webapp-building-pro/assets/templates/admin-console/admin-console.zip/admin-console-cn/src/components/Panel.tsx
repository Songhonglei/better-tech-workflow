export default function Panel({ title, tools, children }: {
  title: React.ReactNode; tools?: React.ReactNode; children: React.ReactNode
}) {
  return (
    <section className="panel" data-reveal="">
      <div className="panel-head"><h2>{title}</h2><span className="spacer" />{tools}</div>
      {children}
    </section>
  )
}
