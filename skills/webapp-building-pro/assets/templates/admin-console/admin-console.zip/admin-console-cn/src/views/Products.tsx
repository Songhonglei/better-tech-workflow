import { useEffect, useRef, useState } from 'react'
import Kit from '../lib/kit.js'
import { matches, products } from '../lib/data.js'
import Panel from '../components/Panel'
import Seg from '../components/Seg'
import type { Product } from '../lib/types'

export default function Products({ query }: { query: string }) {
  const [mode, setMode] = useState('all')
  const table = useRef<HTMLTableElement>(null)
  useEffect(() => { Kit.sortable(table.current) }, [])
  const rows: Product[] = products.filter((p: Product) =>
    (mode === 'all' || p.stock < p.reorder) && matches(p, query))
  return (
    <Panel title="商品目录" tools={
      <Seg id="stockSeg" items={[['all', '全部'], ['low', '低于补货点']]} onPick={setMode} />}>
      <div style={{ overflowX: 'auto' }}><table id="pTable" ref={table}>
        <thead><tr>
          <th data-sort="s">商品</th><th data-sort="s">SKU</th>
          <th className="n" data-sort="n">价格</th><th className="n" data-sort="n">近 30 天销量</th>
          <th style={{ width: '180px' }}>库存与补货点</th>
        </tr></thead>
        <tbody id="pBody">
          {!rows.length
            ? <tr><td colSpan={5} className="empty">{`没有匹配“${query}”的商品`}</td></tr>
            : rows.map(p => {
              const low = p.stock < p.reorder
              const w = Math.min(100, p.stock / Math.max(p.reorder * 2.4, 1) * 100)
              return (
                <tr key={p.sku}>
                  <td>{p.name}</td><td className="num dim">{p.sku}</td>
                  <td className="n num">{'¥' + p.price}</td><td className="n num">{Kit.fmt(p.sold)}</td>
                  <td><div style={{ display: 'flex', alignItems: 'center', gap: '9px' }}>
                    <div className="track" style={{ flex: 1 }}>
                      <i style={{ width: w + '%', background: `var(--${low ? 'neg' : 'accent'})` }} /></div>
                    <span className={'num ' + (low ? 'neg' : 'dim')}
                          style={{ fontSize: '11.5px', width: '34px', textAlign: 'right' }}>{p.stock}</span>
                  </div></td>
                </tr>
              )
            })}
        </tbody>
      </table></div>
    </Panel>
  )
}
