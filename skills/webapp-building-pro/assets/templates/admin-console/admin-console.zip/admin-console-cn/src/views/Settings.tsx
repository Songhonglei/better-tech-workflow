import { useState } from 'react'
import Kit from '../lib/kit.js'
import { PER } from '../lib/data.js'
import Panel from '../components/Panel'
import Seg from '../components/Seg'

const PREFS: [string, string, string, boolean][] = [
  ['digest', '每周摘要', '每周一汇总收入、订单与退款。', true],
  ['alerts', '低库存提醒', 'SKU 低于补货点时通知。', true],
  ['beta', '测试功能', '为工作区开启未正式发布的看板。', false],
]

export default function Settings() {
  const [on, setOn] = useState<Record<string, boolean>>(() => {
    const m: Record<string, boolean> = {}
    PREFS.forEach(([k, , , d]) => { m[k] = !!(localStorage.getItem('nw-' + k) ?? d) })
    return m
  })
  return (
    <div className="g2b">
      <Panel title="偏好设置">
        <div className="form">
          {PREFS.map(([k, t, h]) => (
            <div className="frow" key={k}>
              <div className="fl"><div className="t">{t}</div><div className="h">{h}</div></div>
              <button className={'sw ' + (on[k] ? 'on' : '')} data-k={k} role="switch" aria-label={t}
                      onClick={() => setOn(m => {
                        const v = !m[k]
                        localStorage.setItem('nw-' + k, v ? '1' : '')
                        Kit.toast(t + (v ? '：已开启' : '：已关闭'))
                        return { ...m, [k]: v }
                      })} />
            </div>
          ))}
          <div className="frow">
            <div className="fl"><div className="t">货币</div>
              <div className="h">应用于工作区内所有金额。</div></div>
            <select id="cur" onChange={e => Kit.toast('货币已设为 ' + e.target.value)}>
              <option>CNY ¥</option><option>USD $</option><option>EUR €</option></select>
          </div>
          <div className="frow">
            <div className="fl"><div className="t">每页行数</div>
              <div className="h">应用于所有表格分页。</div></div>
            <input id="rows" type="number" min="5" max="50" defaultValue={PER} style={{ width: '76px' }}
                   onChange={e => Kit.toast('每页 ' + e.target.value + ' 行')} />
          </div>
        </div>
      </Panel>
      <Panel title="外观">
        <div className="form">
          <div className="frow">
            <div className="fl"><div className="t">主题</div>
              <div className="h">图表原地换肤，无需刷新也不会丢失状态。</div></div>
            <Seg id="themeSeg" items={[['light', '浅色'], ['dark', '深色']]}
                 value={Kit.theme()} onPick={(v: string) => Kit.theme(v)} />
          </div>
          <div className="frow">
            <div className="fl"><div className="t">密度</div>
              <div className="h">调整所有表格的行高与留白。</div></div>
            <Seg id="densSeg" items={[['comfortable', '舒适'], ['compact', '紧凑']]}
                 onPick={v => {
                   document.documentElement.style.setProperty('--pad', v === 'compact' ? '13px' : '20px')
                   Kit.toast(v === 'compact' ? '已切换紧凑密度' : '已切换舒适密度')
                 }} />
          </div>
        </div>
      </Panel>
    </div>
  )
}
