import { useEffect, useRef } from 'react'
import Kit from '../lib/kit.js'
import { C, invoices, matches, money, stateLabel } from '../lib/data.js'
import Panel from '../components/Panel'
import Chart from '../components/Chart'
import type { Invoice } from '../lib/types'

export default function Invoices({ query }: { query: string }) {
  const table = useRef<HTMLTableElement>(null)
  useEffect(() => { Kit.sortable(table.current) }, [])
  const buckets: [string, number][] = [['0–20d', 0], ['21–45d', 0], ['46–60d', 0], ['60d+', 0]]
  invoices.forEach((v: Invoice) => { buckets[v.age <= 20 ? 0 : v.age <= 45 ? 1 : v.age <= 60 ? 2 : 3][1] += v.amount })
  const rows: Invoice[] = invoices.filter((v: Invoice) => matches(v, query))
  return (
    <div className="g2">
      <Panel title="未结发票" tools={
        <button className="btn" id="invExport" onClick={() => {
          Kit.download('invoices.csv', Kit.toCSV([['id', 'customer', 'days', 'state', 'amount'],
            ...invoices.map((v: Invoice) => [v.id, v.customer, v.age, v.state, v.amount])]))
          Kit.toast('已导出 ' + invoices.length + ' 张发票')
        }}>导出 CSV</button>}>
        <div style={{ overflowX: 'auto' }}><table id="iTable" ref={table}>
          <thead><tr>
            <th data-sort="s">发票</th><th data-sort="s">客户</th>
            <th className="n" data-sort="n">天数</th><th data-sort="s">状态</th>
            <th className="n" data-sort="n">金额</th>
          </tr></thead>
          <tbody id="iBody">
            {!rows.length
              ? <tr><td colSpan={5} className="empty">{`没有匹配“${query}”的发票`}</td></tr>
              : rows.map(v => (
                <tr key={v.id}>
                  <td className="num">{v.id}</td><td>{v.customer}</td>
                  <td className="n num">{v.age}</td>
                  <td><span className={'status ' + (v.state === 'Overdue' ? 'neg' : v.state === 'Due' ? 'warn' : 'pos')}>
                    {stateLabel(v.state)}</span></td>
                  <td className="n num">{money(v.amount)}</td>
                </tr>
              ))}
          </tbody>
        </table></div>
      </Panel>
      <Panel title="账龄">
        <Chart className="chart" id="ageChart" style={{ height: '242px' }} build={() => ({
          grid: { left: 52, right: 16, top: 12, bottom: 22 },
          tooltip: Object.assign(Kit.base().tooltip, { trigger: 'axis', valueFormatter: (v: number) => money(v) }),
          xAxis: Kit.axis('category', { data: buckets.map(b => b[0]) }),
          yAxis: Kit.axis('value', { axisLabel: { color: C('faint'), fontSize: 10.5,
            fontFamily: C('mono'), formatter: (v: number) => '¥' + v / 1000 + '千' } }),
          series: [{ type: 'bar', data: buckets.map(b => b[1]), barWidth: '46%',
            itemStyle: { borderRadius: [2, 2, 0, 0],
              color: (p: { dataIndex: number }) => [C('accent'), C('accent'), C('warn'), C('neg')][p.dataIndex] } }],
        })} />
      </Panel>
    </div>
  )
}
