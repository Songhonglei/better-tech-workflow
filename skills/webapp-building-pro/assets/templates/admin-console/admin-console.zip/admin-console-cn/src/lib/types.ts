export interface Customer { name: string; initials: string; plan: string; seats: number
                            mrr: number; since: number; health: number }
export interface Order { id: string; customer: string; initials: string; date: string
                         status: string; city: string; total: number }
export interface Product { name: string; sku: string; stock: number; reorder: number
                           sold: number; price: number }
export interface Invoice { id: string; customer: string; amount: number; age: number; state: string }
