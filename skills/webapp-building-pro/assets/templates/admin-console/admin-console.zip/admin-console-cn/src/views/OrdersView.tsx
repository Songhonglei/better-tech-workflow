import { useEffect, useRef } from 'react'
import Kit from '../lib/kit.js'
import { PER } from '../lib/data.js'
import Panel from '../components/Panel'
import Seg from '../components/Seg'
import { OrderRows, Pager, exportOrders, ordersFor } from './Orders'

export default function OrdersView({ filt, setFilt, page, setPage, cityFilt, query }: {
  filt: string; setFilt: (v: string) => void
  page: number; setPage: (p: number) => void
  cityFilt: string | null; query: string
}) {
  const table = useRef<HTMLTableElement>(null)
  useEffect(() => { Kit.sortable(table.current) }, [])
  const rows = ordersFor(filt, cityFilt, query)
  const pages = Math.max(1, Math.ceil(rows.length / PER))
  const pg = Math.min(page, pages)
  return (
    <Panel title="全部订单" tools={<>
      <Seg id="statSeg" items={[['all', '全部'], ['Paid', '已支付'], ['Pending', '待处理'], ['Refunded', '已退款']]}
           onPick={v => { setFilt(v); setPage(1) }} />
      <button className="btn" id="ordExport" onClick={() => exportOrders(rows)}>导出 CSV</button>
    </>}>
      <div style={{ overflowX: 'auto' }}><table id="ordTable" ref={table}>
        <thead><tr>
          <th data-sort="s">订单</th><th data-sort="s">客户</th>
          <th data-sort="s">日期</th><th data-sort="s">状态</th>
          <th className="n" data-sort="n">总额</th>
        </tr></thead>
        <tbody id="ordBody">
          <OrderRows rows={rows.slice((pg - 1) * PER, pg * PER)} cityFilt={cityFilt} query={query} market={false} />
        </tbody>
      </table></div>
      <Pager total={rows.length} page={pg} onPage={setPage} />
    </Panel>
  )
}
