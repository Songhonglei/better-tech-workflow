import { useEffect, useRef } from 'react'
import Kit from '../lib/kit.js'
import { C, SRC, rnd } from '../lib/data.js'
import Panel from '../components/Panel'
import Chart from '../components/Chart'

const FUNNEL: [string, number][] = [['访问', 18204], ['注册', 5410], ['激活', 2980],
  ['订阅', 1240], ['留存 90 天', 918]]
const weeks = ['W1', 'W2', 'W3', 'W4', 'W5', 'W6']
/* 留存热力图的格子也走同一条随机序列，抽一次就定下来。 */
const CELLS: number[][] = []
weeks.forEach((_, y) => weeks.forEach((__, x) => {
  if (x < weeks.length - y) CELLS.push([x, y, Math.round(100 * Math.pow(.82 + rnd() * .06, x))])
}))

export default function Analytics() {
  const table = useRef<HTMLTableElement>(null)
  useEffect(() => { Kit.sortable(table.current) }, [])
  return (
    <>
      <div className="g2b">
        <Panel title="获客漏斗">
          <Chart className="chart" id="fun" build={() => ({
            grid: { left: 88, right: 44, top: 8, bottom: 8 },
            xAxis: Kit.axis('value', { show: false }),
            yAxis: Kit.axis('category', { data: FUNNEL.map(f => f[0]).reverse(),
              axisLabel: { color: C('muted'), fontSize: 11.5 }, axisLine: { show: false } }),
            series: [{ type: 'bar', data: FUNNEL.map(f => f[1]).reverse(), barWidth: 13,
              itemStyle: { color: C('accent'), borderRadius: [0, 2, 2, 0] },
              label: { show: true, position: 'right', color: C('muted'), fontSize: 11,
                fontFamily: C('mono'), formatter: (p: { value: number }) => Kit.fmt(p.value) } }],
          })} />
        </Panel>
        <Panel title="周度同期群留存">
          <Chart className="chart" id="coh" build={() => ({
            grid: { left: 40, right: 14, top: 22, bottom: 26 },
            tooltip: Object.assign(Kit.base().tooltip, { formatter: (p: { value: number[] }) => '留存 ' + p.value[2] + '%' }),
            xAxis: Kit.axis('category', { data: weeks.map((_, i) => '+' + i + '周'), splitArea: { show: false } }),
            yAxis: Kit.axis('category', { data: weeks, splitLine: { show: false } }),
            visualMap: { show: false, min: 30, max: 100,
              inRange: { color: [C('bg'), C('accent-soft'), C('accent')] } },
            series: [{ type: 'heatmap', data: CELLS,
              itemStyle: { borderColor: C('panel'), borderWidth: 2 },
              // The cell fill runs from page background to full accent, so a single
              // label colour is unreadable at one end or the other.
              label: { show: true, fontSize: 10, fontFamily: C('mono'),
                color: (p: { value: number[] }) => p.value[2] > 78 ? C('accent-ink') : C('ink'),
                formatter: (p: { value: number[] }) => p.value[2] } }],
          })} />
        </Panel>
      </div>
      <Panel title="渠道表现">
        <div style={{ overflowX: 'auto' }}><table id="chTable" ref={table}>
          <thead><tr>
            <th data-sort="s">渠道</th><th className="n" data-sort="n">会话</th>
            <th className="n" data-sort="n">注册</th><th className="n" data-sort="n">转化率</th>
            <th className="n" data-sort="n">获客成本</th>
          </tr></thead>
          <tbody>
            {SRC.map(([n, v]: [string, number], i: number) => {
              const sess = Math.round(18204 * v / 100), su = Math.round(sess * (.18 + i * .04))
              return (
                <tr key={n}>
                  <td>{n}</td><td className="n num">{Kit.fmt(sess)}</td>
                  <td className="n num">{Kit.fmt(su)}</td>
                  <td className="n num">{(su / sess * 100).toFixed(1) + '%'}</td>
                  <td className="n num">{'¥' + (18 + i * 11).toFixed(2)}</td>
                </tr>
              )
            })}
          </tbody>
        </table></div>
      </Panel>
    </>
  )
}
