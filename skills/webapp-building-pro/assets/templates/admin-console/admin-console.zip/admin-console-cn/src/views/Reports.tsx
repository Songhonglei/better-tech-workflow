import { useState } from 'react'
import Kit from '../lib/kit.js'
import { repOpt } from '../lib/data.js'
import Panel from '../components/Panel'
import Chart from '../components/Chart'

const REPORTS: [string, string, string][] = [
  ['月度收入回顾', '定时 · 每月 1 日', 'revenue'],
  ['退款原因', '手动', 'refunds'],
  ['企业销售管线', '定时 · 每周一', 'pipeline'],
  ['套餐流失', '手动', 'churn'],
  ['库存周转', '手动', 'inventory'],
  ['客服负载与订单', '手动', 'support'],
]

export default function Reports() {
  const [repI, setRepI] = useState(0)
  const exportCSV = (i: number) => {
    const r = Kit.rng(9000 + i)
    Kit.download(REPORTS[i][2] + '.csv', Kit.toCSV(
      [['month', 'value'], ...Array.from({ length: 12 }, (_, m) => [m + 1, Math.round(1000 + r() * 9000)])]))
    Kit.toast('已导出 ' + REPORTS[i][0])
  }
  return (
    <div className="g2">
      <Panel title="已存报表">
        <div className="form">
          {REPORTS.map(([n, s], i) => (
            <div className="frow" key={n}>
              <div className="fl"><div className="t">{n}</div><div className="h">{s}</div></div>
              <button className="btn" data-rep={i} onClick={() => setRepI(i)}>预览</button>
              <button className="btn" data-exp={i} onClick={() => exportCSV(i)}>导出 CSV</button>
            </div>
          ))}
        </div>
      </Panel>
      <Panel title={<span id="repName">{REPORTS[repI][0]}</span>}>
        <Chart className="chart" id="repChart" build={() => repOpt(repI)} deps={[repI]} />
      </Panel>
    </div>
  )
}
