import { useCallback, useEffect, useRef, useState } from 'react'
import Kit from './lib/kit.js'
import Tool from './lib/tool.js'
import { DEMO, namesToText, normalize, seed, textToNames, uid } from './lib/draw.js'
import * as W from './lib/wheel.js'
import SwitchRow from './components/SwitchRow'

const store = Tool.store('draw-state', null)
const BACK = <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>
const UP = <svg viewBox="0 0 24 24"><path d="M12 19V5M6 11l6-6 6 6" /></svg>
const DOWN = <svg viewBox="0 0 24 24"><path d="M12 5v14M6 13l6 6 6-6" /></svg>

const TTL: Record<string, string> = { draw: '转盘', won: '中奖', setup: '名单与奖品', rec: '中奖记录' }
const SUB: Record<string, string> = { draw: 'LUCKY DRAW', won: 'WINNER', setup: 'SETUP', rec: 'RECORDS' }

interface Prize { id: string; ic: string; name: string; count: number }
interface Rec { n: string; pid: string; prize: string; ic: string; at: number }

export default function App() {
  /* 引擎和 React 共享同一个状态对象：转盘那一层是命令式的，每帧都在读它，
     复制一份进去只会让两边不同步。React 这边用一个计数器逼出重渲染。 */
  const st = useRef(normalize(store.get() || seed())).current
  // 首次渲染就要读 curPrize / restOf，所以状态得在 effect 之前先交给引擎；
  // 宿主元素挂载后再补一次。
  W.bind(st, {}, () => store.set(st))
  const [, force] = useState(0)
  const redraw = useCallback(() => force(n => n + 1), [])
  const save = useCallback(() => { store.set(st); redraw() }, [])

  const [screen, setScreen] = useState('draw')
  const [namesText, setNamesText] = useState(() => namesToText(st))
  const [won, setWon] = useState<{ winners: { n: string }[]; prize: Prize } | null>(null)
  const [recSeen, setRecSeen] = useState(false)

  const screens = useRef<HTMLDivElement>(null)
  const acts = useRef<HTMLSpanElement>(null)
  const modeEl = useRef<HTMLDivElement>(null)
  const hall = useRef<HTMLDivElement>(null)
  const gl = useRef<HTMLCanvasElement>(null)
  const roller = useRef<HTMLDivElement>(null)
  const rollname = useRef<HTMLDivElement>(null)
  const nav = useRef<{ go: (id: string, o?: object) => void; back: () => void; current: () => string } | null>(null)
  const busy = useRef(false)

  /* ── 三维转盘：整台机器由 wheel.js 自己管，React 只给它画布和宿主 ────── */
  useEffect(() => {
    W.bind(st, { gl: gl.current, hall: hall.current, rollname: rollname.current }, () => store.set(st))
    const ok = W.initGL()
    if (!ok) {
      /* 没有 WebGL 就退回滚动点名 —— 宴会厅的那台笔记本什么都可能发生，
         但抽奖不能因此开不了场。 */
      st.mode = 'roll'; save()
      Kit.toast('这台设备不支持 3D，已切到滚动点名')
    }
    applyMode()
    const ro = new ResizeObserver(() => W.fit())
    ro.observe(hall.current!)
    addEventListener('resize', W.fit)
    return () => { ro.disconnect(); removeEventListener('resize', W.fit) }
  }, [])

  useEffect(() => {
    nav.current = Tool.screens(screens.current)
    const onScreen = (e: Event) => {
      const id = (e as CustomEvent).detail
      setScreen(id)
      if (id === 'draw') requestAnimationFrame(W.fit)
    }
    addEventListener('tool:screen', onScreen)
    return () => removeEventListener('tool:screen', onScreen)
  }, [])

  /* 滚动点名那一层是铺满盖住转盘的，所以三样东西要一起换：那一层、画布、中间
     的「抽」。少换一样就会出现「老虎机上面浮着一个转盘按钮」。 */
  const applyMode = () => {
    const wheel = st.mode === 'wheel' && W.glOK()
    if (roller.current) roller.current.hidden = wheel
    if (gl.current) gl.current.style.visibility = wheel ? 'visible' : 'hidden'
    const hub = document.getElementById('spin')
    if (hub) hub.hidden = !wheel
    if (wheel) W.fit()
  }
  useEffect(() => Kit.seg(modeEl.current, (v: string) => {
    st.mode = v; save(); applyMode()
  }), [])

  /* ── 分享链接 / 导出条 / 明暗 ────────────────────────────────────────── */
  useEffect(() => {
    const host = acts.current
    if (!host) return
    Tool.exportBar(host, {
      name: 'lucky-draw',
      poster: () => Tool.poster({
        brand: W.curPrize() ? W.curPrize().name : '抽奖',
        title: st.records[0] ? st.records[0].n : '还没开始',
        subtitle: new Date().toLocaleDateString('zh-CN') + ' · 共 ' + st.names.length + ' 人参与',
        hero: st.records.length ? { value: String(st.records.length), unit: '位', caption: '已产生中奖者' } : null,
        rows: st.records.slice(0, 8).map((r: Rec) => [r.prize, r.n]),
        note: st.rules.noRepeat ? '已开启不重复中奖。' : '',
        footer: '转盘 · LUCKY DRAW',
      }),
      link: async () => Tool.share.link({ names: st.names.map((p: { n: string }) => p.n), prizes: st.prizes }, 'd'),
    })
    /* 切主题时盘上真正变的只有两样：指针的颜色和烘出来的环境图，所以只改该改的，
       并且等 CSS 过渡跑完再动 —— 整台机器重建一次是几百毫秒，会把过渡一起冻住。 */
    let t = 0
    Kit.themeToggle(() => {
      clearTimeout(t)
      t = setTimeout(W.rethemeGL, 260) as unknown as number
    }, host)
    return () => { host.innerHTML = ''; clearTimeout(t) }
  }, [])

  useEffect(() => {
    (async () => {
      const got = await Tool.share.read('d')
      if (got && got.names) {
        st.names = got.names.map((n: string) => ({ n, w: 1 }))
        if (got.prizes && got.prizes.length) st.prizes = got.prizes
        st.records = []; st.pi = 0; save()
        setNamesText(namesToText(st))
        W.buildWheel()
        Kit.toast('已载入分享的名单 · ' + got.names.length + ' 人')
      }
    })()
  }, [])

  /* ── 抽 ─────────────────────────────────────────────────────────────── */
  const setBusy = (v: boolean) => {
    ;['#spin', '#spin2', '#gosetup', '#gorec2'].forEach(id => {
      const el = document.querySelector<HTMLButtonElement>(id); if (el) el.disabled = v
    })
    document.querySelectorAll<HTMLButtonElement>('#mode button, .prow').forEach(b => { b.disabled = v })
  }

  const draw = async () => {
    if (busy.current) return
    if (!st.prizes.length) { Kit.toast('先加一个奖品'); Tool.sound.err(); return }
    if (!W.advancePrize()) { Kit.toast('奖品都抽完了'); Tool.sound.err(); return }
    const prize: Prize = W.curPrize()
    const need = Math.max(1, Math.min(W.restOf(prize), (st.perDraw | 0) || 1))
    if (W.pool().length < need) {
      Kit.toast('池子里不够了 —— 补名单，或关掉「不重复中奖」'); Tool.sound.err(); return
    }
    busy.current = true
    W.setSpinning(true)                 // 整段抽奖期间都满帧
    setBusy(true)

    const winners: { n: string }[] = []
    for (let i = 0; i < need; i++) {
      const target = W.pick()
      if (!target) break
      await (st.mode === 'wheel' && W.glOK() ? W.spinWheel(target) : W.spinRoll(target))
      winners.push(target)
      st.records.unshift({ n: target.n, pid: prize.id, prize: prize.name, ic: prize.ic, at: Date.now() })
      store.set(st)
      if (i < need - 1) {
        W.buildWheel()                     // 中过的人退出后，盘要重画
        await new Promise(r => setTimeout(r, 560))
      }
    }
    busy.current = false
    W.setSpinning(false)
    setBusy(false)
    W.buildWheel(); W.advancePrize(); redraw()
    setWon({ winners, prize })
    nav.current?.go('won')
    Tool.sound.win(); Tool.haptic(40)
    Tool.confetti({
      n: 180,
      colors: [Tool.tone('s1'), Tool.tone('s2'), Tool.tone('s3'),
               Tool.tone('s4'), Tool.tone('s5'), Tool.tone('s7')],
    })
  }

  const prize = W.curPrize() as Prize | undefined
  const sw = won ? W.swatchFor(st.prizes.indexOf(won.prize)) : null

  return (
    <div className="stage">

      <div className="topbar">
        <button className="ib" id="back" hidden={screen === 'draw'}
                onClick={() => { nav.current?.back(); if (nav.current?.current() === 'draw') W.fit() }}>{BACK}</button>
        <div>
          <div className="title" id="ttl">{TTL[screen]}</div>
          <div className="sub" id="sub">{SUB[screen]}</div>
        </div>
        <span className="spacer" />
        <span className="acts" id="acts" ref={acts} />
      </div>

      <div className="screens" id="screens" ref={screens}>

        {/* ── 抽奖台 ──────────────────────────────────────────────────── */}
        <section className="screen" data-screen="draw">
          <div className="twopane rail-right">
            <div className="work">
              <div className="hall" id="hall" ref={hall}>
                <canvas id="gl" ref={gl} />
                <div className="roller" id="roller" ref={roller} hidden>
                  <div className="win" id="rollname" ref={rollname}>准备好了</div>
                </div>
                <div className="hud" id="hud">
                  {prize && <>
                    {prize.ic ? <span className="ic">{prize.ic}</span> : null}
                    <span className="nm">{prize.name}</span>
                    <span className="rest">{'还剩 ' + W.restOf(prize) + ' / ' + prize.count}</span>
                  </>}
                </div>
                <button className="hub" id="spin" onClick={draw}>抽</button>
              </div>
              <div className="bottombar">
                <button className="btn wide primary" id="spin2" onClick={draw}>开始抽奖</button>
                <button className="btn" id="gosetup" onClick={() => {
                  setNamesText(namesToText(st)); nav.current?.go('setup')
                }}>名单与奖品</button>
              </div>
            </div>

            <div className="rail">
              <div className="railbody">
                <div className="seclbl">方式</div>
                <div style={{ padding: '0 16px' }}>
                  <div className="seg" id="mode" ref={modeEl}>
                    <button data-v="wheel" className="on">转盘</button>
                    <button data-v="roll">滚动点名</button>
                  </div>
                </div>
                <div className="seclbl">奖品 · 点一下切到那一项</div>
                <div id="prizerail">
                  {st.prizes.length ? st.prizes.map((p: Prize, i: number) => {
                    const rest = W.restOf(p)
                    return (
                      <button key={p.id} type="button" aria-current={i === st.pi ? 'true' : undefined}
                              className={'prow' + (i === st.pi ? ' on' : '') + (rest === 0 ? ' done' : '')}
                              onClick={() => { st.pi = i; save(); Tool.sound.tick() }}>
                        <span className="pcolor" style={{ background: W.swatchFor(i).css }} />
                        <span className="ic">{p.ic || '·'}</span>
                        <span className="nm">{p.name}</span>
                        <span className="ct">{rest + '/' + p.count}</span>
                      </button>
                    )
                  }) : <p className="hint" style={{ padding: '0 16px' }}>去「名单与奖品」里加一个。</p>}
                </div>
                <div className="seclbl">现场</div>
                <div style={{ padding: '0 16px' }}>
                  <div className="statcard">
                    <div className="lbl">还在池子里</div>
                    <div className="big"><b id="s-pool">{W.pool().length}</b><span>人</span></div>
                    <div className="foot">
                      <span>已中 <b id="s-won">{st.records.length}</b></span>
                      <span>每次抽 <b id="s-per">{st.perDraw}</b></span>
                    </div>
                  </div>
                </div>
                <div className="seclbl">中奖记录</div>
                <div style={{ padding: '0 16px 18px' }}>
                  <button className="btn" id="gorec2"
                          onClick={() => { setRecSeen(true); nav.current?.go('rec') }}>看全部记录</button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ── 中奖 ────────────────────────────────────────────────────── */}
        <section className="screen" data-screen="won">
          <div className="won" id="wonbody">
            {/* 一整屏白纸上放一个名字，是最省事也是最没意思的做法。中奖屏做成一张
                整块的色卡，颜色跟着奖品档走 —— 特等奖永远是万寿菊，一等奖永远是赤陶，
                一场下来观众看颜色就知道在发哪一档。 */}
            {won && sw && (
              <div className="woncard" style={{ background: sw.css, color: sw.fg }}>
                {won.prize.ic ? <div className="ic">{won.prize.ic}</div> : null}
                <div className="lbl">{won.prize.name}</div>
                {won.winners.map((w, i) => <div className="name" key={i}>{w.n}</div>)}
                <div className="rule" />
                <div className="roundno">
                  {'第 ' + st.records.length + ' 位 · 本档还剩 ' + W.restOf(won.prize) + ' 个名额'}
                </div>
              </div>
            )}
          </div>
          <div className="bottombar">
            <button className="btn wide primary" id="nextround"
                    onClick={() => { nav.current?.go('draw', { back: true }); W.fit() }}>下一轮</button>
            <button className="btn" id="gorec"
                    onClick={() => { setRecSeen(true); nav.current?.go('rec') }}>中奖记录</button>
          </div>
        </section>

        {/* ── 名单与奖品 ──────────────────────────────────────────────── */}
        <section className="screen" data-screen="setup">
          <div className="scroll setup">
            <div className="seclbl">名单 · 一行一个，可写「名字,权重」</div>
            <div className="pad" style={{ paddingTop: 0 }}>
              <div className="field">
                <textarea id="names" rows={7} value={namesText}
                          onChange={e => setNamesText(e.target.value)} />
              </div>
              <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                <button className="btn" id="applynames" onClick={() => {
                  const got = textToNames(namesText)
                  if (!got.length) { Kit.toast('名单是空的'); Tool.sound.err(); return }
                  st.names = got; save(); W.buildWheel()
                  Kit.toast('名单 ' + got.length + ' 人已应用')
                }}>应用名单</button>
                <button className="btn" id="demo30" onClick={() => {
                  const got = textToNames(DEMO.join('\n'))
                  setNamesText(DEMO.join('\n'))
                  st.names = got; save(); W.buildWheel()
                  Kit.toast('名单 ' + got.length + ' 人已应用')
                }}>来 30 个示例</button>
                {/* 清空同时抹掉名单和中奖记录 —— 一个不吭声的破坏性按钮是最容易让人后悔的
                    那种。所以它必须说出自己干了什么；本来就没东西可清的时候也要说。 */}
                <button className="btn" id="clearall" onClick={() => {
                  const had = st.names.length, rec = st.records.length
                  if (!had && !rec) { Kit.toast('名单和记录本来就是空的'); Tool.sound.err(); return }
                  setNamesText(''); st.names = []; st.records = []
                  save(); W.buildWheel()
                  Kit.toast('清空了 ' + had + ' 个名字' + (rec ? '和 ' + rec + ' 条中奖记录' : ''))
                }}>清空</button>
              </div>
              <p className="hint" style={{ marginTop: '9px' }}>权重决定扇区的大小 —— 概率是看得见的，不藏在代码里。
                 不写权重默认 1。</p>
            </div>

            <div className="seclbl">奖品</div>
            <div className="pad" style={{ paddingTop: 0 }}>
              <div id="plist">
                {st.prizes.length ? st.prizes.map((p: Prize, i: number) => (
                  <div className="pedit" key={p.id}>
                    <input className="i-ic" value={p.ic || ''} placeholder="🎁" maxLength={4}
                           aria-label="奖品图标"
                           onChange={e => { p.ic = e.target.value; save() }} />
                    <input className="i-nm" value={p.name} placeholder="奖品名称" aria-label="奖品名称"
                           onChange={e => { p.name = e.target.value || '奖品'; save() }} />
                    <input className="i-ct" type="number" min={1} max={999} value={p.count}
                           aria-label="名额"
                           onChange={e => { p.count = Math.max(1, Math.min(999, parseInt(e.target.value) || 1)); save() }} />
                    <button className="miniib" type="button" title="上移" aria-label="上移" disabled={i === 0}
                            onClick={() => {
                              const cur = st.prizes[st.pi]
                              ;[st.prizes[i], st.prizes[i - 1]] = [st.prizes[i - 1], st.prizes[i]]
                              st.pi = Math.max(0, st.prizes.indexOf(cur)); save(); Tool.sound.tick()
                            }}>{UP}</button>
                    <button className="miniib" type="button" title="下移" aria-label="下移"
                            disabled={i === st.prizes.length - 1}
                            onClick={() => {
                              const cur = st.prizes[st.pi]
                              ;[st.prizes[i], st.prizes[i + 1]] = [st.prizes[i + 1], st.prizes[i]]
                              st.pi = Math.max(0, st.prizes.indexOf(cur)); save(); Tool.sound.tick()
                            }}>{DOWN}</button>
                    {/* 记录里还留着这一档的中奖人。删掉档位不删人 —— 名字是现场念出去过的，
                        它比配置更真。 */}
                    <button className="miniib danger" type="button" title="删除" aria-label="删除"
                            dangerouslySetInnerHTML={{ __html: Tool.ICON.trash }}
                            onClick={() => {
                              const gone = st.prizes[i]
                              st.prizes.splice(i, 1)
                              st.pi = Math.min(st.pi, Math.max(0, st.prizes.length - 1))
                              save(); Kit.toast('已删除「' + gone.name + '」')
                            }} />
                  </div>
                )) : <p className="hint">一个奖品都没有，先加一个。</p>}
              </div>
              <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginTop: '4px' }}>
                <button className="btn" id="paddbtn" onClick={() => {
                  st.prizes.push({ id: uid('p'), ic: '🎁', name: '新奖品', count: 1 })
                  save(); Tool.sound.tick()
                }}>＋ 添加奖品</button>
              </div>
              <div className="field" style={{ marginTop: '14px' }}>
                <label>每次开奖抽几个</label>
                <input id="perdraw" type="number" min="1" max="20" value={st.perDraw}
                       onChange={e => {
                         st.perDraw = Math.max(1, Math.min(20, parseInt(e.target.value) || 1)); save()
                       }} />
              </div>
              <p className="hint">名额抽满了自动跳到下一档。图标那一格写个 emoji 就行，也可以留空。</p>
            </div>

            <div className="seclbl">规则</div>
            <div className="pad" style={{ paddingTop: 0 }} id="rules">
              <SwitchRow label="不重复中奖" desc="中过的人退出后续轮次" on={st.rules.noRepeat}
                         onChange={v => { st.rules.noRepeat = v; save(); W.buildWheel() }} />
              <SwitchRow label="按权重设置概率" desc="扇区大小 = 权重占比，概率是看得见的"
                         on={st.rules.weighted}
                         onChange={v => { st.rules.weighted = v; save(); W.buildWheel() }} />
              <SwitchRow label="扇区上显示概率" on={st.rules.showProb}
                         onChange={v => { st.rules.showProb = v; save(); W.buildWheel() }} />
              <SwitchRow label="音效" on={!Tool.sound.muted}
                         onChange={v => { Tool.sound.muted = !v; redraw() }} />
            </div>

            <div className="seclbl">谁已经中过了</div>
            <div className="pad" style={{ paddingTop: 0 }} id="chips">
              {st.records.length
                ? [...new Set(st.records.map((r: Rec) => r.n))].map(n => (
                    <span className="namechip won" key={n as string}><span>{n as string}</span></span>))
                : <p className="hint">还没有人中奖。</p>}
            </div>
            <div style={{ height: '20px' }} />
          </div>
          <div className="bottombar">
            <button className="btn wide primary" id="backtodraw"
                    onClick={() => { nav.current?.back(); W.fit() }}>回到抽奖台</button>
          </div>
        </section>

        {/* ── 记录 ────────────────────────────────────────────────────── */}
        <section className="screen" data-screen="rec">
          <div className="scroll" id="recbody">
            {recSeen && <>
              <div className="seclbl">{'中奖记录 · ' + st.records.length + ' 条'}</div>
              {!st.records.length && (
                <div className="empty" dangerouslySetInnerHTML={{
                  __html: Tool.ICON.dice + '<div>还没有人中奖。</div>',
                }} />
              )}
              <div className="reclist">
                {st.records.map((r: Rec, i: number) => (
                  <div className="recrow" key={i}>
                    <span className="r">{String(st.records.length - i).padStart(2, '0')}</span>
                    <span className="n">{r.n}</span>
                    <span className="t">{(r.ic ? r.ic + ' ' : '') + r.prize}</span>
                    <span className="t">{new Date(r.at).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                ))}
              </div>
            </>}
          </div>
          <div className="bottombar">
            <button className="btn wide primary" id="expcsv" onClick={() => {
              Kit.download('中奖记录.csv', Kit.toCSV([['序号', '姓名', '奖项', '时间'],
                ...st.records.slice().reverse().map((r: Rec, i: number) =>
                  [i + 1, r.n, r.prize, new Date(r.at).toLocaleString('zh-CN')])]))
              Kit.toast('已导出 CSV')
            }}>导出 CSV</button>
            <button className="btn" id="clearrec" onClick={() => {
              st.records = []; st.pi = 0; save(); W.buildWheel()
            }}>清空记录</button>
          </div>
        </section>
      </div>
    </div>
  )
}
